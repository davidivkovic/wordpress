<?php
/**
 * The template for displaying the footer for coming soon page.
 *
 * Contains the closing of the id=main div and all content after
 *
 * @package Davenport
 */
?>
<?php wp_footer(); ?>
</body>
</html>

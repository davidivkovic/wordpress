<?php
/**
 * Davenport functions
 *
 * @package Davenport
 */

/**
 * WordPress content width configuration
 */
if (!isset($content_width))
	$content_width = 1140; /* pixels */

/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
if(!function_exists('davenport_setup')):
function davenport_setup() {

	/**
	 * Make theme available for translation
	 * Translations can be filed in the /languages/ directory
	 * If you're building a theme based on Davenport, use a find and replace
	 * to change 'davenport' to the name of your theme in all the template files
	 */
	load_theme_textdomain('davenport', get_template_directory() . '/languages');

	/**
	 * Add default posts and comments RSS feed links to head
	 */
	add_theme_support('automatic-feed-links');

	/**
	 * Enable support for Post Thumbnails on posts and pages
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support('post-thumbnails');

  /**
   * Enable support Gutenberg features
   */
  add_theme_support( 'align-wide' );
  add_theme_support( 'editor-styles' );

	/**
	 * Enable support for JetPack Infinite Scroll
	 *
	 * @link https://jetpack.me/support/infinite-scroll/
	 */
	add_theme_support( 'infinite-scroll', array(
	    'container' => 'content',
	    'footer' => 'page',
	) );

	/**
	 * Enable support for Title Tag
	 *
	 */
	add_theme_support( 'title-tag' );

	/**
	 * Enable support for Logo
	 */
	add_theme_support( 'custom-header', array(
	    'default-image' =>  get_template_directory_uri() . '/img/logo.png',
            'width'         => 165,
            'flex-width'    => true,
            'flex-height'   => false,
            'header-text'   => false,
	));

	/**
	 *	Woocommerce support
	 */
	add_theme_support( 'woocommerce' );

	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );

  if (!function_exists('davenport_woocommerce_single_gallery_thumbnail_size')) :
  /**
   * Change the gallery thumbnail image size.
   */
  function davenport_woocommerce_single_gallery_thumbnail_size( $size ) {
      return array(
          'width'  => 300,
          'height' => 300,
          'crop'   => 1,
      );
  }
  endif;
  add_filter( 'woocommerce_get_image_size_gallery_thumbnail', 'davenport_woocommerce_single_gallery_thumbnail_size' );

	/**
	 * Enable support for Post Formats
	 */
	add_theme_support('post-formats', array('aside', 'image', 'gallery', 'video', 'audio', 'quote', 'link', 'status', 'chat'));

	/**
	 * Theme images sizes
	 */
	add_image_size( 'davenport-blog-thumb', 1140, 694, true);
	add_image_size( 'davenport-blog-thumb-grid', 555, 360, true);
	add_image_size( 'davenport-blog-thumb-widget', 220, 180, true);
  add_image_size( 'davenport-blog-thumb-masonry', 360, 0, false);

	/**
	 * Theme menus locations
	 */
	register_nav_menus( array(
        'main' => esc_html__('Main Menu', 'davenport'),
        'top' => esc_html__('Top Menu', 'davenport'),
        'footer' => esc_html__('Footer Menu', 'davenport'),
	) );

  // Filters the oEmbed process to run the responsive_embed() function
  add_filter('embed_oembed_html', 'davenport_responsive_embed', 10, 3);

  // Activate theme
  update_option('davenport_license_key_status', 'activated');

}
endif;
add_action('after_setup_theme', 'davenport_setup');

/*
* Change posts excerpt length
*/
if(!function_exists('davenport_new_excerpt_length')):
function davenport_new_excerpt_length($length) {
	$post_excerpt_length = get_theme_mod('blog_posts_excerpt_limit', 35);

	return $post_excerpt_length;
}
endif;
add_filter('excerpt_length', 'davenport_new_excerpt_length');

/**
 * Enqueue scripts and styles
 */
if(!function_exists('davenport_scripts')):
function davenport_scripts() {

  // Add default fonts if user not installed required plugins
  if ( !class_exists( 'Kirki' ) ) {
    wp_enqueue_style('davenport-fonts', davenport_editor_fonts_url());
  }

	wp_enqueue_style('bootstrap', get_template_directory_uri() . '/css/bootstrap.css');
	wp_enqueue_style('owl-carousel', get_template_directory_uri() . '/js/owl-carousel/owl.carousel.css');
	wp_enqueue_style('davenport-stylesheet', get_stylesheet_uri(), array(), '1.0.2', 'all');
	wp_enqueue_style('davenport-responsive', get_template_directory_uri() . '/responsive.css', '1.0.2', 'all');

	if ( true == get_theme_mod( 'animations_css3', true ) )  {
		wp_enqueue_style('davenport-animations', get_template_directory_uri() . '/css/animations.css');
	}

	wp_enqueue_style('font-awesome', get_template_directory_uri() . '/css/font-awesome.css');
	wp_enqueue_style('davenport-select2', get_template_directory_uri() . '/js/select2/select2.css'); // special version, must be prefixed with theme prefix
	wp_enqueue_style('swiper', get_template_directory_uri() . '/css/idangerous.swiper.css');

  // Animation on scroll
  wp_enqueue_style('aos', get_template_directory_uri() . '/js/aos/aos.css');
  wp_register_script('aos', get_template_directory_uri() . '/js/aos/aos.js', array(), '2.3.1', true);
  wp_enqueue_script('aos');

	add_thickbox();

	// Registering scripts to include it in correct order later
	wp_register_script('bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js', array(), '3.1.1', true);
	wp_register_script('easing', get_template_directory_uri() . '/js/easing.js', array(), '1.3', true);
	wp_register_script('davenport-select2', get_template_directory_uri() . '/js/select2/select2.min.js', array(), '3.5.1', true);  // special version, must be prefixed with theme prefix
	wp_register_script('owl-carousel', get_template_directory_uri() . '/js/owl-carousel/owl.carousel.min.js', array(), '2.0.0', true);


	// Enqueue scripts in correct order
	wp_enqueue_script('davenport-script', get_template_directory_uri() . '/js/template.js', array('jquery', 'bootstrap', 'easing', 'davenport-select2', 'owl-carousel'), '1.3', true);

	if (is_singular() && comments_open() && get_option('thread_comments')) {
		wp_enqueue_script('comment-reply');
	}

}
endif;
add_action('wp_enqueue_scripts', 'davenport_scripts');

/**
 * Enqueue scripts and styles for admin area
 */
if(!function_exists('davenport_admin_scripts')):
function davenport_admin_scripts() {
	wp_register_style( 'davenport-style-admin', get_template_directory_uri() .'/css/admin.css' );
	wp_enqueue_style( 'davenport-style-admin' );
	wp_register_style('font-awesome', get_template_directory_uri() . '/css/font-awesome.css');
	wp_enqueue_style( 'font-awesome' );

	wp_register_script('davenport-template-admin', get_template_directory_uri() . '/js/template-admin.js', array(), '1.0', true);
	wp_enqueue_script('davenport-template-admin');
}
endif;
add_action( 'admin_init', 'davenport_admin_scripts' );

if(!function_exists('davenport_load_wp_media_files')):
function davenport_load_wp_media_files() {
  wp_enqueue_media();
}
endif;
add_action( 'admin_enqueue_scripts', 'davenport_load_wp_media_files' );

/**
 * Disable built-in WordPress plugins
 */
if(!function_exists('davenport_disable_builtin_plugins')):
function davenport_disable_builtin_plugins() {

  // Deactivate Gutenberg to avoid conflicts, since it's already built in to WordPress 5.x
  if(version_compare(get_bloginfo('version'), '5.0', ">=")) {
      deactivate_plugins( '/gutenberg/gutenberg.php' );
  }

}
endif;
add_action( 'admin_init', 'davenport_disable_builtin_plugins' );

/**
 * Display navigation to next/previous pages when applicable
 */
if(!function_exists('davenport_content_nav')):
function davenport_content_nav( $nav_id ) {
  global $wp_query, $post;

  // Loading library to check active plugins
  include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

  // Don't print empty markup on single pages if there's nowhere to navigate.
  if ( is_single() ) {
    $previous = ( is_attachment() ) ? get_post( $post->post_parent ) : get_adjacent_post( false, '', true );
    $next = get_adjacent_post( false, '', false );

    if ( ! $next && ! $previous )
      return;
  }

  // Don't print empty markup in archives if there's only one page.
  if ( $wp_query->max_num_pages < 2 && ( is_home() || is_archive() || is_search() ) )
    return;

  $nav_class = ( is_single() ) ? 'navigation-post' : 'navigation-paging';

  ?>
  <nav id="<?php echo esc_attr( $nav_id ); ?>" class="<?php echo esc_attr($nav_class); ?>">

  <?php if ( is_single() ) : // navigation links for single posts ?>
  <div class="nav-post-wrapper">
    <?php
    // Previous post nav
    $prev_post = get_previous_post();
    if ( is_a( $prev_post , 'WP_Post' ) ):
    ?>
    <div class="nav-post nav-post-prev davenport-post<?php if(is_a( $prev_post , 'WP_Post' ) && !has_post_thumbnail( $prev_post->ID )) { echo ' no-image'; } ?>">
      <a href="<?php echo esc_url(get_permalink($prev_post->ID)); ?>">

      <?php
      $image = wp_get_attachment_image_src( get_post_thumbnail_id( $prev_post->ID ), 'davenport-blog-thumb-widget');

      if(has_post_thumbnail( $prev_post->ID )) {
          $image_bg ='background-image: url('.esc_url($image[0]).');';

          $post_image_html = '<div class="davenport-post-image-wrapper"><div class="davenport-post-image" data-style="'.esc_attr($image_bg).'"></div></div>';
      } else {
          $image_bg = '';
          $post_image_html = '';
      }

      $prev_post_title = the_title_attribute(array('echo' => false, 'post' => $prev_post->ID));

      ?>
      <div class="nav-post-button-title"><i class="fa fa-arrow-left" aria-hidden="true"></i><?php esc_html_e( 'Previous Article', 'davenport' ); ?></div>
      <div class="nav-post-button">
      <?php echo wp_kses($post_image_html, davenport_esc_data()); ?>
      <div class="nav-post-details">
        <div class="post-date"><?php echo davenport_get_post_date($prev_post->ID); ?></div>
        <div class="nav-post-name"><?php echo esc_html($prev_post_title); ?></div>
      </div>
      </div>
    </a>
    </div>
    <?php
    endif;
    ?>
    <?php
    // Next post nav
    $next_post = get_next_post();
    if ( is_a( $next_post , 'WP_Post' ) ):
    ?>
    <div class="nav-post nav-post-next davenport-post<?php if(is_a( $next_post , 'WP_Post' ) && !has_post_thumbnail( $next_post->ID )) { echo ' no-image'; } ?>">
    <a href="<?php echo esc_url(get_permalink($next_post->ID)); ?>">
    <?php
      $image = wp_get_attachment_image_src( get_post_thumbnail_id( $next_post->ID ), 'davenport-blog-thumb-widget');

      if(has_post_thumbnail( $next_post->ID )) {
          $image_bg ='background-image: url('.esc_url($image[0]).');';

          $post_image_html = '<div class="davenport-post-image-wrapper"><div class="davenport-post-image" data-style="'.esc_attr($image_bg).'"></div></div>';
      } else {
          $image_bg = '';
          $post_image_html = '';
      }

      $next_post_title = the_title_attribute(array('echo' => false, 'post' => $next_post->ID));
      ?>
      <div class="nav-post-button-title"><?php esc_html_e( 'Next Article', 'davenport' ); ?><i class="fa fa-arrow-right" aria-hidden="true"></i></div>
      <div class="nav-post-button">
      <div class="nav-post-details">
        <div class="post-date"><?php echo davenport_get_post_date($next_post->ID); ?></div>
        <div class="nav-post-name"><?php echo esc_html($next_post_title); ?></div>
      </div>
      <?php echo wp_kses($post_image_html, davenport_esc_data()); ?>
      </div>
    </a>
    </div>
    <?php
    endif;
    ?>
  </div>
  <?php elseif ( $wp_query->max_num_pages > 1 && ( is_home() || is_archive() || is_search() ) ) : // navigation links for home, archive, and search pages ?>
  <div class="clear"></div>
  <div class="container-fluid">
    <div class="row">
      <?php if ( function_exists( 'wp_pagenavi' ) ): ?>
        <div class="col-md-12 nav-pagenavi">
        <?php wp_pagenavi(); ?>
        </div>
      <?php else: ?>
        <div class="col-md-6 nav-post-prev">
        <?php if ( get_next_posts_link() ) : ?>
        <?php next_posts_link( esc_html__( 'Older posts', 'davenport' ) ); ?>
        <?php endif; ?>
        </div>

        <div class="col-md-6 nav-post-next">
        <?php if ( get_previous_posts_link() ) : ?>
        <?php previous_posts_link( esc_html__( 'Newer posts', 'davenport' ) ); ?>
        <?php endif; ?>
        </div>
      <?php endif; ?>

    </div>
  </div>
  <?php endif; ?>

  </nav>
  <?php
}
endif;

/**
 * Template for comments and pingbacks.
 *
 * Used as a callback by wp_list_comments() for displaying the comments.
 */
if(!function_exists('davenport_comment')):
function davenport_comment( $comment, $args, $depth ) {
  $GLOBALS['comment'] = $comment;

  if ( 'pingback' == $comment->comment_type || 'trackback' == $comment->comment_type ) : ?>

  <li id="comment-<?php comment_ID(); ?>" <?php comment_class(); ?>>
    <div class="comment-body">
      <?php esc_html_e( 'Pingback:', 'davenport' ); ?> <?php comment_author_link(); ?> <?php edit_comment_link( esc_html__( 'Edit', 'davenport' ), '<span class="edit-link">', '</span>' ); ?>
    </div>

  <?php else : ?>

  <li id="comment-<?php comment_ID(); ?>" <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ); ?>>
    <article id="div-comment-<?php comment_ID(); ?>" class="comment-body">

      <div class="comment-meta clearfix">
        <div class="reply">
          <?php edit_comment_link( esc_html__( 'Edit', 'davenport' ), '', '' ); ?>
          <?php comment_reply_link( array_merge( $args, array( 'add_below' => 'div-comment', 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
        </div><!-- .reply -->
        <div class="comment-author vcard">

          <?php if ( 0 != $args['avatar_size'] ) echo get_avatar( $comment, 100 ); ?>

        </div><!-- .comment-author -->

        <div class="comment-metadata">

          <div class="date"><i class="fa fa-calendar-o"></i><a href="<?php echo esc_url( get_comment_link( $comment->comment_ID ) ); ?>"><time datetime="<?php comment_time( 'c' ); ?>"><?php printf( _x( '%1$s %2$s %3$s', '1: date, 2: at, 3: time', 'davenport' ), get_comment_date(), esc_html__('at', 'davenport'), get_comment_time() ); ?></time></a></div>
          <div class="author">
          <?php printf('%s', sprintf( '<cite class="fn">%s</cite>', get_comment_author_link() ) ); ?>
          </div>

          <?php if ( '0' == $comment->comment_approved ) : ?>
          <p class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'davenport' ); ?></p>
          <?php endif; ?>
          <div class="comment-content">
            <?php comment_text(); ?>
          </div>
        </div><!-- .comment-metadata -->

      </div><!-- .comment-meta -->

    </article><!-- .comment-body -->

  <?php
  endif;
}
endif;

// Set/Get current post details for global usage in templates (post position in loop, etc)
if(!function_exists('davenport_set_post_details')):
function davenport_set_post_details($details) {
	global $davenport_post_details;

	$davenport_post_details = $details;
}
endif;

if(!function_exists('davenport_get_post_details')):
function davenport_get_post_details() {
	global $davenport_post_details;

	return $davenport_post_details;
}
endif;

/**
 * Registers an editor stylesheet
 */
if(!function_exists('davenport_add_editor_styles')):
function davenport_add_editor_styles() {
    add_editor_style( 'custom-editor-style.css' );
    add_editor_style( davenport_editor_fonts_url() );

    // Load dynamic editor styles with fonts selected by user to match frontend fonts
    $wp_upload_dir = wp_upload_dir();
    $editor_cache_file_name = 'style-editor-cache-'.wp_get_theme()->get('TextDomain');
    $css_editor_cache_file_url = $wp_upload_dir['baseurl'].'/'.$editor_cache_file_name.'.css';
    add_editor_style( $css_editor_cache_file_url );
}
add_action('admin_init', 'davenport_add_editor_styles');
endif;

/**
 * Social services list
 */
if(!function_exists('davenport_social_services_list')):
function davenport_social_services_list() {
  // You can add more social services here, array keys must beequal to Font Awesome icons names, without 'fa-' prefix
  // Available icons list: https://fontawesome.com/v4.7.0/icons/
  $social_services_array = array(
      'facebook' => esc_attr__( 'Facebook', 'davenport' ),
      'vk' => esc_attr__( 'VKontakte', 'davenport' ),
      'google-plus' => esc_attr__( 'Google+', 'davenport' ),
      'twitter' => esc_attr__( 'Twitter', 'davenport' ),
      'linkedin' => esc_attr__( 'LinkedIn', 'davenport' ),
      'dribbble' => esc_attr__( 'Dribbble', 'davenport' ),
      'behance' => esc_attr__( 'Behance', 'davenport' ),
      'instagram' => esc_attr__( 'Instagram', 'davenport' ),
      'tumblr' => esc_attr__( 'Tumblr', 'davenport' ),
      'pinterest' => esc_attr__( 'Pinterest', 'davenport' ),
      'vimeo-square' => esc_attr__( 'Vimeo', 'davenport' ),
      'youtube' => esc_attr__( 'Youtube', 'davenport' ),
      'twitch' => esc_attr__( 'Twitch', 'davenport' ),
      'skype' => esc_attr__( 'Skype', 'davenport' ),
      'flickr' => esc_attr__( 'Flickr', 'davenport' ),
      'deviantart' => esc_attr__( 'Deviantart', 'davenport' ),
      '500px' => esc_attr__( '500px', 'davenport' ),
      'etsy' => esc_attr__( 'Etsy', 'davenport' ),
      'telegram' => esc_attr__( 'Telegram', 'davenport' ),
      'odnoklassniki' => esc_attr__( 'Odnoklassniki', 'davenport' ),
      'houzz' => esc_attr__( 'Houzz', 'davenport' ),
      'slack' => esc_attr__( 'Slack', 'davenport' ),
      'qq' => esc_attr__( 'QQ', 'davenport' ),
      'github' => esc_attr__( 'Github', 'davenport' ),
      'whatsapp' => esc_attr__( 'WhatsApp', 'davenport' ),
      'telegram' => esc_attr__( 'Telegram', 'davenport' ),
      'rss' => esc_attr__( 'RSS', 'davenport' ),
      'envelope-o' => esc_attr__( 'Email', 'davenport' ),
      'medium' => esc_attr__( 'Medium', 'davenport' ),
      'address-card-o' => esc_attr__( 'Other', 'davenport' ),
  );

  return $social_services_array;
}
endif;


/**
 * Theme homepage blocks list
 */
if(!function_exists('davenport_blocks_list')):
function davenport_blocks_list() {

  $davenport_blocks_array = array(
      'postsline' => esc_html__( '[POSTS] Posts Line #1', 'davenport' ),
      'postsline2' => esc_html__( '[POSTS] Posts Line #2', 'davenport' ),
      'largepostsslider' => esc_html__( '[POSTS] Large Posts Slider', 'davenport' ),
      'fullwidthpostsslider' => esc_html__( '[POSTS] Fullwidth Posts Slider', 'davenport' ),
      'carousel' => esc_html__( '[POSTS] Posts Carousel', 'davenport' ),
      'carousel2' => esc_html__( '[POSTS] Posts Cards Carousel', 'davenport' ),
      'posthighlight' => esc_html__( '[POSTS] Post Highlight Slider', 'davenport' ),
      'postsgrid1' => esc_html__( '[POSTS] Posts Grid #1', 'davenport' ),
      'postsgrid2' => esc_html__( '[POSTS] Posts Grid #2', 'davenport' ),
      'postsgrid3' => esc_html__( '[POSTS] Posts Grid #3', 'davenport' ),
      'postsgrid4' => esc_html__( '[POSTS] Posts Grid #4', 'davenport' ),
      'postsgrid5' => esc_html__( '[POSTS] Posts Grid #5', 'davenport' ),
      'postsgrid6' => esc_html__( '[POSTS] Posts Grid #6', 'davenport' ),
      'postsgrid7' => esc_html__( '[POSTS] Posts Grid #7', 'davenport' ),
      'postsgrid8' => esc_html__( '[POSTS] Posts Grid #8', 'davenport' ),
      'postsmasonry1' => esc_html__( '[POSTS] Posts Masonry #1', 'davenport' ),
      'postsmasonry2' => esc_html__( '[POSTS] Posts Masonry #2', 'davenport' ),
      'postsmasonry3' => esc_html__( '[POSTS] Posts Masonry #3', 'davenport' ),
      'showcase1' => esc_html__( '[POSTS] Showcase #1', 'davenport' ),
      'showcase2' => esc_html__( '[POSTS] Showcase #2', 'davenport' ),
      'showcase3' => esc_html__( '[POSTS] Showcase #3', 'davenport' ),
      'showcase4' => esc_html__( '[POSTS] Showcase #4', 'davenport' ),
      'showcase5' => esc_html__( '[POSTS] Showcase #5', 'davenport' ),
      'showcase6' => esc_html__( '[POSTS] Showcase #6', 'davenport' ),
      'html' => esc_html__( '[HTML] HTML Block', 'davenport' ),
      'blog' => esc_html__( '[MISC] Blog Listing', 'davenport' ),
      'subscribe' => esc_html__( '[MISC] Subscribe Block', 'davenport' ),
      'categories' => esc_html__( '[MISC] Categories Block', 'davenport' ),
      'instagram' => esc_html__( '[MISC] Instagram Block', 'davenport' ),
  );

  return $davenport_blocks_array;
}
endif;

/**
 * Theme posts types list for homepage blocks
 */
if(!function_exists('davenport_post_types_list')):
function davenport_post_types_list() {

  $davenport_post_types_array = array(
      'latest' => esc_html__( 'Latest', 'davenport' ),
      'featured' => esc_html__( 'Featured', 'davenport' ),
      'editorspicks' => esc_html__( "Editors picks", 'davenport' ),
      'promoted' => esc_html__( 'Promoted', 'davenport' ),
      'popular' => esc_html__( 'Popular', 'davenport' ),
      'liked' => esc_html__( 'Most liked', 'davenport' ),
      'trending' => esc_html__( 'Trending', 'davenport' ),
      'random' => esc_html__( 'Random', 'davenport' ),
  );

  return $davenport_post_types_array;
}
endif;

/**
 * Set content width
 */
if(!function_exists('davenport_set_content_width')):
function davenport_set_content_width($width) {
    global $content_width;// Global here used to define new content width for global WordPress system variable

    $content_width = $width;
}
endif;

/**
 * Adds a responsive embed wrapper around oEmbed content
 */
if(!function_exists('davenport_responsive_embed')):
function davenport_responsive_embed($html, $url, $attr) {
    return $html!=='' ? '<div class="embed-container">'.$html.'</div>' : '';
}
endif;

/**
 * Get theme font settings and defaults
 */
if(!function_exists('davenport_get_fonts_settings')):
function davenport_get_fonts_settings($font_type) {

  $headers_font_default = 'Aleo';
  $body_font_default = 'Source Serif Pro';
  $additional_font_default = 'Barlow';

  $headers_font = get_theme_mod('headers_font', array(
      'font-family'    => $headers_font_default,
      'variant'        => '700',
  ));

  // Body font
  $body_font = get_theme_mod('body_font', array(
      'font-family'    => $body_font_default,
      'variant'        => 'regular',
      'font-size'      => '16px',
  ));

  // Additional font
  $additional_font = get_theme_mod('additional_font', array(
      'font-family'    => $additional_font_default,
      'variant'        => '500',
  ));

  $fonts_defaults['headers_font'] = $headers_font;
  $fonts_defaults['body_font'] = $body_font;
  $fonts_defaults['additional_font'] = $additional_font;

  return $fonts_defaults[$font_type];
}
endif;

/**
 * Add Custom fonts to editor
 */
if(!function_exists('davenport_editor_fonts_url')):
function davenport_editor_fonts_url() {

  $fonts_url = '';

  // Fonts and default fonts configuration
  $headers_font = davenport_get_fonts_settings('headers_font');

  // Body font
  $body_font = davenport_get_fonts_settings('body_font');

  // Additional font
  $additional_font = davenport_get_fonts_settings('additional_font');

  $font_families[] = $headers_font['font-family'].':'.$headers_font['variant'];
  $font_families[] = $body_font['font-family'].':'.$body_font['variant'];
  $font_families[] = $additional_font['font-family'].':'.$additional_font['variant'];

  $query_args = array(
    'family' => rawurlencode( implode( '|', $font_families ) ),
    'subset' => rawurlencode( 'latin,latin-ext' ),
  );

  $fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );

  return esc_url_raw( $fonts_url );
}
endif;

/**
 * Load theme plugins installation.
 */
require get_template_directory() . '/inc/theme-plugins.php';

/**
 * Load theme options.
 */
require get_template_directory() . '/inc/theme-options.php';

/**
 * Load theme functions.
 */
require get_template_directory() . '/inc/theme-functions.php';

/**
 * Load theme homepage blocks.
 */
require get_template_directory() . '/inc/theme-blocks.php';

/**
 * Load theme sidebars
 */
require get_template_directory() . '/inc/theme-sidebars.php';

/**
 * Load theme AMP functions.
 */
require get_template_directory() . '/inc/theme-amp.php';

/**
 * Load theme dynamic CSS.
 */
require get_template_directory() . '/inc/theme-css.php';

/**
 * Load theme dynamic JS.
 */
require get_template_directory() . '/inc/theme-js.php';

/**
 * Theme dashboard.
 */
require get_template_directory() . '/inc/theme-dashboard/class-theme-dashboard.php';

/**
 * Load additional theme modules.
 */

# Module - Category settings
require get_template_directory() . '/inc/modules/category/category-settings.php';

# Module - Mega Menu
if(get_theme_mod('module_mega_menu', true)) {
  require get_template_directory() . '/inc/modules/mega-menu/custom-menu.php';
}

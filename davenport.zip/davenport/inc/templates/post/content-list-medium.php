<?php
/**
 * Post template: List Medium
 */

?>
<?php

$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'davenport-blog-thumb-grid');

if(has_post_thumbnail( $post->ID )) {
    $image_bg ='background-image: url('.esc_url($image[0]).');';
    $post_class = '';
}
else {
    $image_bg = '';
    $post_class = ' davenport-post-no-image';
}

$categories_list = davenport_get_the_category_list( $post->ID );

// Show post format
$current_post_format = get_post_format($post->ID) ? get_post_format($post->ID) : 'standard';

$post_class .= ' format-'.$current_post_format;

echo '<div class="davenport-list-post davenport-list-medium-post davenport-post'.esc_attr($post_class).'"'.davenport_add_aos(false).'>';

if(has_post_thumbnail( $post->ID )) {
    echo '<div class="davenport-post-image-wrapper">';

    if(get_theme_mod('blog_posts_review', true)) {
        do_action('davenport_post_review_rating'); // this action called from plugin
    }

    echo '<a href="'.esc_url(get_permalink($post->ID)).'"><div class="davenport-post-image" data-style="'.esc_attr($image_bg).'"></div></a></div>';
}

// Post details
echo '<div class="davenport-post-details">';

echo '<div class="post-categories">'.wp_kses($categories_list, davenport_esc_data()).'</div>';

echo '<h3 class="post-title entry-title"><a href="'.esc_url(get_permalink($post->ID)).'">'.wp_kses_post($post->post_title).'</a></h3>';

echo '<div class="post-date">'.davenport_get_post_date($post->ID).'</div>';
?>
<?php if(get_theme_mod('blog_posts_excerpt', 'content') !== 'none'): ?>
<?php echo '<div class="post-excerpt">';

echo wp_kses_post( davenport_get_the_excerpt(150, $post->ID) );

?>
</div>
<?php endif; // after post-excerpt ?>
</div>

</div>



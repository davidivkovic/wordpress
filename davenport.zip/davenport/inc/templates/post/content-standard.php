<?php
/**
 * Post template: Grid large (Standard blog layout)
 */

?>
<?php

$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'davenport-blog-thumb');

if(has_post_thumbnail( $post->ID )) {
    $image_bg ='background-image: url('.esc_url($image[0]).');';
    $post_class = '';
}
else {
    $image_bg = '';
    $post_class = ' davenport-post-no-image';
}

$categories_list = davenport_get_the_category_list( $post->ID );

// Show post format
$current_post_format = get_post_format($post->ID) ? get_post_format($post->ID) : 'standard';
$post_format_icon = '';

if(in_array($current_post_format, davenport_get_mediaformats())) {
    $post_format_icon = '<div class="davenport-post-format-icon"></div>';
}

$post_class .= ' format-'.$current_post_format;

echo '<div class="davenport-grid-post davenport-standard-post davenport-grid-large-post davenport-post'.esc_attr($post_class).'"'.davenport_add_aos(false).'>';

if(has_post_thumbnail( $post->ID )) {
    echo '<div class="davenport-post-image-wrapper">';

    if(get_theme_mod('blog_posts_review', true)) {
        do_action('davenport_post_review_rating'); // this action called from plugin
    }

    echo '<a href="'.esc_url(get_permalink($post->ID)).'"><div class="davenport-post-image"><img src="'.esc_url($image[0]).'" alt="'.esc_attr($post->post_title).'"/>'.wp_kses_post($post_format_icon).'</div></a><div class="post-categories">'.wp_kses($categories_list, davenport_esc_data()).'</div></div>';
} else {
    echo '<div class="post-categories">'.wp_kses($categories_list, davenport_esc_data()).'</div>';
}

// Post details
echo '<div class="davenport-post-details">

    <div class="post-date">'.davenport_get_post_date($post->ID).'</div>

    <h3 class="post-title entry-title"><a href="'.esc_url(get_permalink($post->ID)).'">'.wp_kses_post($post->post_title).'</a></h3>';
if(get_theme_mod('blog_posts_author', false)):
?>
<div class="post-author">
    <span class="vcard">
        <?php echo esc_html__('By', 'davenport'); ?> <span class="fn"><?php echo get_the_author_posts_link(); ?></span>
    </span>
</div>
<?php
endif;

echo '</div>';
// END - Post details
?>
<?php if(get_theme_mod('blog_posts_excerpt', 'content') !== 'none'): ?>
<?php echo '<div class="post-excerpt">';

if(get_theme_mod('blog_posts_default_excerpt', true)) {
  the_excerpt('');
} else {
  echo wp_kses_post( davenport_get_the_excerpt(400, $post->ID) );
}

if(get_the_excerpt() !== get_the_content()):
    ?>
    <div class="post-readmore">
        <a href="<?php the_permalink(); ?>" class="more-link btn"><?php esc_html_e('Read more', 'davenport'); ?></a>
        <?php
        // Post details bottom
        get_template_part( 'inc/templates/part/post-details-bottom-inline' );
        ?>
    </div>
    <?php
endif;
?>
</div>

<?php endif; // after post-excerpt ?>

</div>

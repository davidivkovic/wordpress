<?php
/**
 * Post template: Shortline
 */

?>
<?php

$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'davenport-blog-thumb-widget');

if(has_post_thumbnail( $post->ID )) {
    $image_bg ='background-image: url('.esc_url($image[0]).');';
    $post_class = '';
}
else {
    $image_bg = '';
    $post_class = ' davenport-post-no-image';
}

$categories_list = davenport_get_the_category_list( $post->ID );

echo '<div class="davenport-shortline-post davenport-post'.esc_attr($post_class).'"'.davenport_add_aos(false).'>';

if(has_post_thumbnail( $post->ID )) {
  echo '<div class="davenport-post-image-wrapper"><a href="'.esc_url(get_permalink($post->ID)).'"><div class="davenport-post-image" data-style="'.esc_attr($image_bg).'"></div></a></div>';
}

// Post details
echo '<div class="davenport-post-details">

     <div class="post-date">'.davenport_get_post_date($post->ID).'</div>

     <h3 class="post-title entry-title"><a href="'.esc_url(get_permalink($post->ID)).'">'.wp_kses_post($post->post_title).'</a></h3>';

echo '</div>';
// END - Post details


echo '</div>';

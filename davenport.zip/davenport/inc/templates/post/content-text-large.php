<?php
/**
 * Post template: Text Large (large title, date and read more button)
 */

?>
<?php

echo '<div class="davenport-text-post davenport-text-large-post davenport-post"'.davenport_add_aos(false).'>';

// Post details
echo '<div class="davenport-post-details">

    <div class="post-date">'.davenport_get_post_date($post->ID).'</div>
    <h3 class="post-title entry-title"><a href="'.esc_url(get_permalink($post->ID)).'">'.wp_kses_post($post->post_title).'</a></h3>';
?>
<a href="<?php the_permalink(); ?>" class="more-link btn"><?php esc_html_e('Read more', 'davenport'); ?></a>
<?php
echo '</div>';
// END - Post details

echo '</div>';

<?php
/**
 * Post template: Text
 */

?>
<?php

$categories_list = davenport_get_the_category_list( $post->ID );

echo '<div class="davenport-text-post davenport-post"'.davenport_add_aos(false).'>';

echo '<div class="post-categories">'.wp_kses($categories_list, davenport_esc_data()).'</div>';

// Post details
echo '<div class="davenport-post-details">

     <h3 class="post-title entry-title"><a href="'.esc_url(get_permalink($post->ID)).'">'.wp_kses_post($post->post_title).'</a></h3>';

echo '<div class="post-date">'.davenport_get_post_date($post->ID).'</div>';

echo '</div>';
// END - Post details

echo '</div>';

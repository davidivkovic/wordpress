<?php
/**
 * Post header template: Post header template with image and details
 */

// Transparent header
$blog_post_transparent_header = get_theme_mod('blog_post_transparent_header', false);

// Demo settings
if ( defined('DEMO_MODE') && isset($_GET['blog_post_transparent_header']) ) {
    if($_GET['blog_post_transparent_header'] == 0) {
      $blog_post_transparent_header = false;
    }
    if($_GET['blog_post_transparent_header'] == 1) {
      $blog_post_transparent_header = true;
    }
}

// Blog post header layout
$blog_post_header_layout = get_theme_mod('blog_post_header_layout', 'incontent');

// Demo settings
if ( defined('DEMO_MODE') && isset($_GET['blog_post_header_layout']) ) {
  $blog_post_header_layout = $_GET['blog_post_header_layout'];
}

// Don't allow transparent header for blog post header layout with image in content
if($blog_post_header_layout !== 'inheader') {
    $blog_post_transparent_header = false;
}

// Header image
$header_background_image = get_post_meta( get_the_ID(), '_davenport_header_image', true );

if(isset($header_background_image) && ($header_background_image!== '')) {
    $header_background_image_style = 'background-image: url('.$header_background_image.');';
    $header_background_class = ' with-bg';

} else {
    $header_background_image_style = '';
    $header_background_class = ' without-bg';
}

// Header width
$blog_post_header_width = get_theme_mod('blog_post_header_width', 'boxed');

// Demo settings
if ( defined('DEMO_MODE') && isset($_GET['blog_post_header_width']) ) {
    $blog_post_header_width = $_GET['blog_post_header_width'];
}

// Blog post header width
if($blog_post_header_width == 'fullwidth') {
    $container_class = 'container-fluid';
} else {
    $container_class = 'container';
}

// Don't allow boxed header for transparent header
if($header_background_class !== ' without-bg' && $blog_post_transparent_header) {
    $container_class = 'container-fluid';
}

?>
<div class="<?php echo esc_attr($container_class); ?> container-page-item-title<?php echo esc_attr($header_background_class); ?>" data-style="<?php echo esc_attr($header_background_image_style); ?>">
    <?php
    if(get_theme_mod('blog_post_review', true)) {
        do_action('davenport_post_review_rating'); // this action called from plugin
    }
    ?>
    <div class="row">
        <div class="col-md-12 col-overlay">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="page-item-title-single">
                            <?php
                            $categories_list = davenport_get_the_category_list();
                            ?>
                            <div class="davenport-post-single davenport-post">
                                <div class="post-categories"><?php echo wp_kses($categories_list, davenport_esc_data()); ?></div>
                                <div class="davenport-post-details">
                                    <div class="post-date"><?php echo davenport_get_post_date(); ?></div>
                                    <h1 class="post-title entry-title"><?php the_title(); ?></h1>
                                    <?php
                                    if(get_theme_mod('blog_posts_author', false)):
                                    ?>
                                    <div class="post-author">
                                        <span class="vcard">
                                            <?php echo esc_html__('By', 'davenport'); ?> <span class="fn"><?php echo get_the_author_posts_link(); ?></span>
                                        </span>
                                    </div>
                                    <?php
                                    endif;
                                    ?>
                                    <?php
                                    // Post details bottom
                                    get_template_part( 'inc/templates/part/post-details-single-bottom-inline' );
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

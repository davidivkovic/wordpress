<?php
/**
 * Post header template: Post header template (without image)
 */

?>
<div class="container-page-item-title container-page-item-title-inside without-bg">
    <div class="page-item-title-single page-item-title-single-inside">
        <?php
        $categories_list = davenport_get_the_category_list();
        ?>
        <div class="davenport-post-single davenport-post">
            <div class="post-categories"><?php echo wp_kses($categories_list, davenport_esc_data()); ?></div>
            <div class="davenport-post-details">
                <h1 class="post-title entry-title"><?php the_title(); ?></h1>
                <?php
                // Post details bottom
                get_template_part( 'inc/templates/part/post-details-single-bottom-inline-alt' );
                ?>
            </div>
        </div>
    </div>
</div>

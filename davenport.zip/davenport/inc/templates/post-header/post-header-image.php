<?php
/**
 * Post header template: Post header template with image only
 */

// Header image
$header_background_image = get_post_meta( get_the_ID(), '_davenport_header_image', true );

if(has_post_thumbnail()) {
    $header_background_image_style = 'background-image: url('.$header_background_image.');';
    $header_background_class = ' with-bg';

} else {
    $header_background_image_style = '';
    $header_background_class = ' without-bg';
}

// Header width
$blog_post_header_width = get_theme_mod('blog_post_header_width', 'boxed');

// Demo settings
if ( defined('DEMO_MODE') && isset($_GET['blog_post_header_width']) ) {
    $blog_post_header_width = $_GET['blog_post_header_width'];
}

// Blog post header width
if($blog_post_header_width == 'fullwidth') {
    $container_class = 'container-fluid';
} else {
    $container_class = 'container';
}
?>
<div class="<?php echo esc_attr($container_class); ?> container-page-item-title container-page-item-title-image-only<?php echo esc_attr($header_background_class); ?>" data-style="<?php echo esc_attr($header_background_image_style); ?>">
    <?php
    if(get_theme_mod('blog_post_review', true)) {
        do_action('davenport_post_review_rating'); // this action called from plugin
    }
    ?>
    <div class="col-overlay">
    </div>
</div>

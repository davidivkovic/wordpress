<?php
/**
 * Theme Plugins installation
 */

/**
 * Plugin recomendations
 **/
require_once(get_template_directory().'/inc/tgmpa/class-tgm-plugin-activation.php');

if(!function_exists('davenport_register_required_plugins')):
function davenport_register_required_plugins() {

    /**
     * Array of plugin arrays. Required keys are name and slug.
     */
    $plugins = array(
        array(
            'name'                  => esc_html__('Davenport Custom Metaboxes', 'davenport'),
            'slug'                  => 'cmb2',
            'source'                => get_template_directory() . '/inc/plugins/cmb2.zip',
            'required'              => true,
            'version'               => '2.6.0',
        ),
        array(
            'name'                  => esc_html__('Davenport Theme Settings (Kirki Customizer Framework)', 'davenport'),
            'slug'                  => 'kirki',
            'source'                => get_template_directory() . '/inc/plugins/kirki.zip',
            'required'              => true,
        ),
        array(
            'name'                  => esc_html__('Davenport Theme Addons', 'davenport'),
            'slug'                  => 'davenport-theme-addons',
            'source'                => get_template_directory() . '/inc/plugins/davenport-theme-addons.zip',
            'required'              => true,
            'version'               => '1.2.4',
        ),
        array(
            'name'                  => esc_html__('Davenport AMP - Accelerated Mobile Pages support', 'davenport'),
            'slug'                  => 'amp',
            'required'              => false,
        ),
        array(
            'name'                  => esc_html__('Envato Market - Automatic theme updates', 'davenport'),
            'slug'                  => 'envato-market',
            'source'                => get_template_directory() . '/inc/plugins/envato-market.zip',
            'required'              => false,
            'version'               => '2.0.1',
        ),
        array(
            'name'                  => esc_html__('Davenport Page Navigation', 'davenport'),
            'slug'                  => 'wp-pagenavi',
            'required'              => false,
        ),
        array(
            'name'                  => esc_html__('Davenport Translation Manager', 'davenport'),
            'slug'                  => 'loco-translate',
            'required'              => false,
        ),
        array(
            'name'                  => esc_html__('Instagram Feed', 'davenport'),
            'slug'                  => 'instagram-feed',
            'required'              => false,
        ),
        array(
            'name'                  => esc_html__('MailChimp for WordPress', 'davenport'),
            'slug'                  => 'mailchimp-for-wp',
            'required'              => false,
        ),
        array(
            'name'                  => esc_html__('WordPress LightBox', 'davenport'),
            'slug'                  => 'responsive-lightbox',
            'required'              => false
        ),
        array(
            'name'                  => esc_html__('Contact Form 7', 'davenport'),
            'slug'                  => 'contact-form-7',
            'required'              => false,
        ),
        array(
            'name'                  => esc_html__('Regenerate Thumbnails', 'davenport'),
            'slug'                  => 'regenerate-thumbnails',
            'required'              => false,
        )

    );

    // Add Gutenberg for old WordPress versions
    if(version_compare(get_bloginfo('version'), '5.0', "<")) {
        $plugins[] = array(
            'name'                  => esc_html__('Gutenberg - Advanced WordPress Content Editor', 'davenport'),
            'slug'                  => 'gutenberg',
            'required'              => false,
        );
    }

    /**
     * Array of configuration settings.
     */
    $config = array(
        'domain'            => 'davenport',
        'default_path'      => '',
        'menu'              => 'install-required-plugins',
        'has_notices'       => true,
        'dismissable'  => true,
        'is_automatic'      => false,
        'message'           => ''
    );

    tgmpa( $plugins, $config );

}
endif;
add_action('tgmpa_register', 'davenport_register_required_plugins');

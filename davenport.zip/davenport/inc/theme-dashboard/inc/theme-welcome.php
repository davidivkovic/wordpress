<?php
/**
 * Theme dashboard welcome section
 *
 * @package Davenport
 */

?>
<?php
// Theme Activation
if(isset($_REQUEST['act']) && $_REQUEST['act'] == 'registration_complete') {
	update_option('davenport_license_key_status', 'activated');
	delete_option('davenport_update');
	delete_option('davenport_update_cache_date');
}

if(isset($_REQUEST['act']) && $_REQUEST['act'] == 'registration_reset') {
	delete_option('davenport_license_key_status');
}

if(isset($_REQUEST['act']) && $_REQUEST['act'] == 'update_reset') {
	delete_option('davenport_update');
	delete_option('davenport_update_cache_date');
}

?>
<h2 class="nav-tab-wrapper">
	<a href="<?php echo esc_url(admin_url( 'themes.php?page=davenport_dashboard' )); ?>" class="nav-tab nav-tab-active"><?php esc_html_e( 'Getting started', 'davenport' ); ?></a>
	<a href="<?php echo esc_url(admin_url( 'customize.php?autofocus[panel]=theme_settings_panel' )); ?>" class="nav-tab"><?php esc_html_e( 'Theme options', 'davenport' ); ?></a>
	<?php if(get_option( 'davenport_license_key_status', false ) !== 'activated'):?>
	<a href="<?php echo esc_url(admin_url( 'themes.php?page=davenport_activate_theme' )); ?>" class="nav-tab"><?php esc_html_e( 'Theme activation', 'davenport' ); ?></a>
	<?php endif; ?>
	<a href="<?php echo esc_url(admin_url( 'themes.php?page=davenport_system_information' )); ?>" class="nav-tab"><?php esc_html_e( 'System information', 'davenport' ); ?></a>

</h2>

<div class="theme-welcome-wrapper">
	<div class="feature-section two-col">
		<div class="col">
			<?php if(get_option( 'davenport_license_key_status', false ) !== 'activated'): ?>
			<h3 class="text-color-highlight"><?php esc_html_e( 'First of all - Activate your theme', 'davenport' ); ?></h3>
			<p>
				<?php
				esc_html_e( 'Register your purchase to get themes updates notifications, import theme demos and get access to premium dedicated support.', 'davenport' );
				?>
			</p>
			<a class="button button-primary" href="<?php echo esc_url( admin_url( 'themes.php?page=davenport_activate_theme' ) ) ?>" target="_blank"><?php esc_html_e( 'Activate Theme', 'davenport' ); ?></a>
			<?php endif; ?>

			<h3><?php esc_html_e( 'Step 1 - Install Required Plugins', 'davenport' ); ?></h3>
			<p>
				<?php
				esc_html_e( 'Our theme has some required and optional plugins to function properly. Please install theme required plugins.', 'davenport' );
				?>
			</p>
			<?php if(TGM_Plugin_Activation::get_instance()->is_tgmpa_complete()): ?>
			<a class="button button-secondary" disabled href="#"><?php esc_html_e( 'Plugins installed', 'davenport' ); ?></a>
			<?php else: ?>
			<a class="button button-primary" href="<?php echo esc_url( admin_url( 'themes.php?page=install-required-plugins&plugin_status=install' ) ) ?>" target="_blank"><?php esc_html_e( 'Install Plugins', 'davenport' ); ?></a>
			<?php endif; ?>
			<h3><?php esc_html_e( 'Step 2 - Import Demo Data (Optional)', 'davenport' ); ?></h3>
			<p><?php _e( 'We prepared several demos for you to start with. Demo contain sample content, widgets, sliders and theme settings. You can import it with 1 click in our famouse 1-Click Demo Data installer.', 'davenport' );
			?></p>

			<?php if(function_exists('davenport_ta_init')): ?>
			<a class="button button-primary" href="<?php echo esc_url( admin_url( 'themes.php?page=radium_demo_installer' ) ) ?>" target="_blank"><?php esc_html_e( 'Import Demo Data', 'davenport' ); ?></a>
			<?php else: ?>
			<a class="button button-secondary" disabled href="#"><?php esc_html_e( 'Plugins not installed', 'davenport' ); ?></a>
			<?php endif; ?>


			<h3><?php esc_html_e( 'Got questions? We\'re here to help you!', 'davenport' ); ?></h3>
			<p class="about"><?php esc_html_e( 'Check our Help Center articles. If you can\'t find solution for your problem feel free to contact your dedicated support manager.', 'davenport' ); ?></p>

			<a href="<?php echo esc_url( 'http://support.creanncy.com/' ); ?>" target="_blank" class="button button-secondary"><?php esc_html_e( 'Visit Help Center', 'davenport' ); ?></a>

		</div>
		<div class="col">
			<h3><?php esc_html_e( 'Customize Your Site', 'davenport' ); ?></h3>
			<p><?php esc_html_e( 'You can easy manage all theme options in WordPress Customizer, that allows you to preview any changes that you make on the fly.', 'davenport' ); ?></p>
			<p>
				<a href="<?php echo esc_url( admin_url( 'customize.php?autofocus[panel]=theme_settings_panel' ) ); ?>" class="button button-primary"><?php esc_html_e( 'Manage Theme Options', 'davenport' ); ?></a>
			</p>
			<h3><?php esc_html_e( 'Read Theme Documentation', 'davenport' ); ?></h3>
			<p class="about"><?php esc_html_e( 'Please read our detailed step by step theme documentation first to understand how to use the theme and all its features.', 'davenport' ); ?></p>

			<a href="<?php echo esc_url( 'http://creanncy.com/go/davenport-docs/' ); ?>" target="_blank" class="button button-secondary"><?php esc_html_e( 'Read Documentation', 'davenport' ); ?></a>

			<h3><?php esc_html_e( 'Speed Up, Optimize and Secure your website', 'davenport' ); ?></h3>
			<p class="about"><?php esc_html_e( 'Get maximum from your website with our professional Premium "All in one" WordPress Security, Speed and SEO optimization services.', 'davenport' ); ?></p>

			<a href="<?php echo esc_url( 'http://creanncy.com/go/website-boost/' ); ?>" target="_blank" class="button button-secondary"><?php esc_html_e( 'Learn more', 'davenport' ); ?></a>


		</div>
	</div>
	<hr>

</div>

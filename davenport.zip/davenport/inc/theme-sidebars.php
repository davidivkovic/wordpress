<?php
/**
 * Theme Sidebars
 */

if(!function_exists('davenport_sidebars_init')):
function davenport_sidebars_init() {

    register_sidebar(
      array(
        'name' => esc_html__( 'Default Blog sidebar', 'davenport' ),
        'id' => 'main-sidebar',
        'description' => esc_html__( 'Widgets in this area will be shown in the left or right site column on: Main Blog page, Archives, Search.', 'davenport' )
      )
    );

    register_sidebar(
      array(
        'name' => esc_html__( 'Single Blog Post sidebar', 'davenport' ),
        'id' => 'post-sidebar',
        'description' => esc_html__( 'Widgets in this area will be shown in the left or right site column on: Single Blog Post.', 'davenport' )
      )
    );

    register_sidebar(
      array(
        'name' => esc_html__( 'Page sidebar', 'davenport' ),
        'id' => 'page-sidebar',
        'description' => esc_html__( 'Widgets in this area will be shown in the left or right site column on: Page.', 'davenport' )
      )
    );

    register_sidebar(
      array(
        'name' => esc_html__( 'WooCommerce sidebar', 'davenport' ),
        'id' => 'woocommerce-sidebar',
        'description' => esc_html__( 'Widgets in this area will be shown in the left or right site column for woocommerce pages.', 'davenport' )
      )
    );

    register_sidebar(
      array(
        'name' => esc_html__( 'Footer sidebar #1', 'davenport' ),
        'id' => 'footer-sidebar',
        'description' => esc_html__( 'Widgets in this area will be shown in site footer in 4 columns.', 'davenport' )
      )
    );

    register_sidebar(
      array(
        'name' => esc_html__( 'Footer sidebar #2', 'davenport' ),
        'id' => 'footer-sidebar-2',
        'description' => esc_html__( 'Widgets in this area will be shown in site footer in 4 column after Footer sidebar #1.', 'davenport' )
      )
    );

    // Mega Menu sidebars
    if(get_theme_mod('module_megamenu_sidebars', 1) > 0) {
        for ($i = 1; $i <= get_theme_mod('module_megamenu_sidebars', 1); $i++) {
            register_sidebar(
              array(
                'name' => esc_html__( 'Mega Menu sidebar #', 'davenport' ).$i,
                'id' => 'megamenu_sidebar_'.$i,
                'description' => esc_html__( 'You can use this sidebar to display widgets inside megamenu items in menus.', 'davenport' )
              )
            );
        }
    }

}
endif;
add_action( 'widgets_init', 'davenport_sidebars_init' );

<?php
/**
 * Theme homepage blocks
 **/

/**
 * Subscribe block display
 */
if(!function_exists('davenport_block_subscribe_display')):
function davenport_block_subscribe_display($settings = '') {
  ?>
  <div class="container davenport-subscribe-block-container davenport-block"<?php davenport_add_aos(); ?>>
    <?php if(!empty($settings['block_title'])): ?>
    <div class="row">
    <?php
      echo '<div class="davenport-block-title">';
      echo '<h3>'.esc_html($settings['block_title']).'</h3>';
      if(!empty($settings['block_subtitle'])) {
        echo '<h4>'.esc_html($settings['block_subtitle']).'</h4>';
      }
      echo '</div>';
    ?>
    </div>
    <?php endif; ?>
    <div class="davenport-subscribe-block">
    <div class="davenport-subscribe-block-icon">
      <i class="fa fa-envelope-o"></i>
    </div>
    <?php echo do_shortcode(get_theme_mod('subscribeblock_html', '')); ?>
    </div>
  </div>
  <?php
}
endif;

/**
 * Homepage featured categories block display
 */
if(!function_exists('davenport_block_categories_display')):
function davenport_block_categories_display($settings = '') {

    $categories = get_theme_mod('featured_categories', array());
    $categories_count = count($categories);

    if(!empty($categories) && $categories_count > 0) {

        echo '<div class="davenport-featured-categories-wrapper davenport-block"'.davenport_add_aos(false).'>';
        echo '<div class="container">';
        echo '<div class="row">';

        if(!empty($settings['block_title'])) {
          echo '<div class="davenport-block-title">';
          echo '<h3>'.esc_html($settings['block_title']).'</h3>';
          if(!empty($settings['block_subtitle'])) {
            echo '<h4>'.esc_html($settings['block_subtitle']).'</h4>';
          }
          echo '</div>';
        }

        if($categories_count % 3 == 0) {
            $col_class = 'col-md-4';
        } else {
            $col_class = 'col-md-3';
        }

        foreach ($categories as $category) {

            $category_title = get_the_category_by_ID( $category );

            if(!empty($category_title)) {

              $category_link = get_category_link( $category );

              $category_image = get_term_meta ( $category, '_davenport_category_image', true );

              if(isset($category_image) && ($category_image !== '')) {
                  $category_style = 'background-image: url('.$category_image.');';
              } else {
                  $category_style = '';
              }

              $category_color = get_term_meta ( $category, '_davenport_category_color', true );

              if(isset($category_color) && ($category_color !== '')) {
                  $category_badge_style = 'background-color: '.$category_color.';';
              } else {
                  $category_badge_style = '';
              }

              $category_obj = get_category($category);

              if(!empty($category_obj)) {
                $category_counter = $category_obj->category_count;

                echo '<div class="'.esc_attr($col_class).'">';
                echo '<div class="davenport-featured-category davenport-image-wrapper" '.davenport_add_aos(false).'><a href="'.esc_url($category_link).'" class="davenport-featured-category-image-link davenport-image" data-style="'.esc_attr($category_style).'"></a>';
                echo '<div class="davenport-featured-category-info"><a href="'.esc_url($category_link).'" class="davenport-featured-category-link">'.esc_html($category_title).'</a><div class="davenport-featured-category-counter" data-style="'.esc_attr($category_badge_style).'">'.esc_html($category_counter).'</div></div>';
                echo '</div>';
                echo '</div>';
              }

            }


        }

        echo '</div>';
        echo '</div>';
        echo '</div>';
    }

}
endif;

/**
 * Footer Instagram block display
 */
if(!function_exists('davenport_block_instagram_display')):
function davenport_block_instagram_display($settings = '') {

    // Instagram feed
    echo '<div class="davenport-instagram-block-wrapper davenport-block"'.davenport_add_aos(false).'>';
    if(!empty($settings['block_title'])) {
      echo '<div class="container">';
      echo '<div class="row">';
      echo '<div class="davenport-block-title">';
      echo '<h3>'.esc_html($settings['block_title']).'</h3>';
      if(!empty($settings['block_subtitle'])) {
        echo '<h4>'.esc_html($settings['block_subtitle']).'</h4>';
      }
      echo '</div>';
      echo '</div>';
      echo '</div>';
    }

    echo '<div class="container">';

    echo do_shortcode('[instagram-feed]');
    echo '</div>';

    echo '</div>';

}
endif;

/**
 * Postsline #1 block display
 */
if(!function_exists('davenport_block_postsline_display')):
function davenport_block_postsline_display($settings = '') {

  $args = davenport_get_wpquery_args($settings);

  $posts_query = new WP_Query;
  $posts = $posts_query->query($args);

  $total_posts = count($posts);

  if($posts_query->have_posts()) {

    $unique_block_id = rand(10000, 900000);
    ?>
    <div class="davenport-postline-block-wrapper"<?php davenport_add_aos(true);?>>
      <div class="container">
        <div class="row">
          <div class="davenport-postline-block davenport-postline-block-<?php echo esc_attr($unique_block_id); ?> davenport-block clearfix">
            <div class="owl-carousel">
            <?php
            while ($posts_query->have_posts()) {
                  $posts_query->the_post();

                  $post = get_post();

                  $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'davenport-blog-thumb-grid');

                  if(has_post_thumbnail( $post->ID )) {
                      $image_bg ='background-image: url('.esc_url($image[0]).');';
                      $post_class = '';
                  }
                  else {
                      $image_bg = '';
                      $post_class = ' davenport-post-no-image';
                  }

                  $categories_list = davenport_get_the_category_list( $post->ID );
                  ?>

                  <div class="davenport-post<?php echo esc_attr($post_class); ?>">
                    <div class="davenport-postline-block-left">
                      <div class="post-date"><?php echo davenport_get_post_date($post->ID); ?></div>
                      <div class="davenport-postline-block-title">
                        <div class="davenport-block-title"><h3><?php echo esc_html($settings['block_title']); ?></h3></div>
                      </div>
                      <?php
                      // Post details bottom
                      get_template_part( 'inc/templates/part/post-details-bottom-inline' );
                      ?>
                    </div>
                    <div class="davenport-postline-block-right">

                      <div class="davenport-postline-details">
                        <div class="post-categories"><?php echo wp_kses($categories_list, davenport_esc_data()); ?></div>
                        <h3 class="post-title"><a href="<?php echo esc_url(get_permalink($post->ID)); ?>"><?php echo esc_html($post->post_title); ?></a></h3>
                      </div>

                      <?php if(has_post_thumbnail( $post->ID )): ?>
                      <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="davenport-post-image-link">
                        <div class="davenport-post-image" data-style="<?php echo esc_attr($image_bg); ?>"></div>
                      </a>
                      <?php endif; ?>
                    </div>
                  </div>
            <?php
            }
            ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php
      if($total_posts > 1) {
        wp_add_inline_script( 'davenport-script', '(function($){
        $(document).ready(function() {

            "use strict";

            var owlpostslider = $(".davenport-postline-block.davenport-postline-block-'.esc_js($unique_block_id).' .owl-carousel").owlCarousel({
                loop: true,
                items: 1,
                autoplay: true,
                autowidth: false,
                autoplaySpeed: 1000,
                navSpeed: 5000,
                nav: false,
                dots: false,
                navText: false,
                responsive: {
                    1199:{
                        items:1
                    },
                    979:{
                        items:1
                    },
                    768:{
                        items:1
                    },
                    479:{
                        items:1
                    },
                    0:{
                        items:1
                    }
                }
            });

            AOS.refresh();

        });})(jQuery);');
      } else {
        wp_add_inline_script( 'davenport-script', '(function($){
            $(document).ready(function() {

               "use strict";

               $(".davenport-postline-block.davenport-postline-block-'.esc_js($unique_block_id).' .owl-carousel").show();

               AOS.refresh();

            });})(jQuery);');
      }

    } // have_posts

}
endif;

/**
 * Postsline #2 block display
 */
if(!function_exists('davenport_block_postsline2_display')):
function davenport_block_postsline2_display($settings = '') {

  $args = davenport_get_wpquery_args($settings);

  $posts_query = new WP_Query;
  $posts = $posts_query->query($args);

  $total_posts = count($posts);

  if($posts_query->have_posts()) {

    $unique_block_id = rand(10000, 900000);
    ?>
    <div class="davenport-postline2-block-wrapper"<?php davenport_add_aos(true);?>>
      <div class="container-fluid">
        <div class="row">
          <div class="davenport-postline2-block davenport-postline-block-<?php echo esc_attr($unique_block_id); ?> davenport-block clearfix">
            <div class="owl-carousel">
            <?php
            while ($posts_query->have_posts()) {
                  $posts_query->the_post();

                  $post = get_post();

                  echo '<div class="col-md-12">';

                  get_template_part( 'inc/templates/post/content', 'list-small' );

                  echo '</div>';

                  ?>
            <?php
            }
            ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php
      if($total_posts > 1) {
        wp_add_inline_script( 'davenport-script', '(function($){
        $(document).ready(function() {

            "use strict";

            var owlpostslider = $(".davenport-postline2-block.davenport-postline-block-'.esc_js($unique_block_id).' .owl-carousel").owlCarousel({
                loop: true,
                items: 3,
                autoplay: true,
                autowidth: false,
                autoplaySpeed: 1000,
                navSpeed: 5000,
                nav: false,
                dots: false,
                navText: false,
                responsive: {
                    1199:{
                        items:4
                    },
                    979:{
                        items:3
                    },
                    768:{
                        items:2
                    },
                    479:{
                        items:1
                    },
                    0:{
                        items:1
                    }
                }
            });

            AOS.refresh();

        });})(jQuery);');
      } else {
        wp_add_inline_script( 'davenport-script', '(function($){
            $(document).ready(function() {

               "use strict";

               $(".davenport-postline-block.davenport2-postline-block-'.esc_js($unique_block_id).' .owl-carousel").show();

               AOS.refresh();

            });})(jQuery);');
      }

    } // have_posts

}
endif;

/**
 * Helper function to render posts blocks output
 */
if(!function_exists('davenport_posts_block_renderer')):
function davenport_posts_block_renderer($block_id = '', $settings = array()) {

        $args = davenport_get_wpquery_args($settings);

        $posts_query = new WP_Query;
        $posts = $posts_query->query($args);

        // Disable load more if specified offset
        if(!empty($settings['block_posts_offset'])) {
          $settings['block_posts_loadmore'] = 'no';
        }

        if($posts_query->have_posts()) {

              $unique_block_id = rand(10000, 900000);

              echo '<div class="davenport-'.esc_attr($block_id).'-block-wrapper davenport-'.esc_attr($block_id).'-block-wrapper-'.esc_html($unique_block_id).' davenport-block">';

              if(!empty($settings['block_title'])) {
                echo '<div class="container container-title">';
                echo '<div class="row">';
                echo '<div class="davenport-block-title">';
                echo '<h3>'.esc_html($settings['block_title']).'</h3>';
                if(!empty($settings['block_subtitle'])) {
                  echo '<h4>'.esc_html($settings['block_subtitle']).'</h4>';
                }
                echo '</div>';
                echo '</div>';
                echo '</div>';
              }

              echo '<div class="container container-content">';
              echo '<div class="row">';

              $i = 0;
              $post_template = $block_id;

              while ($posts_query->have_posts()){
                  $posts_query->the_post();

                  $i++;

                  // Mixed templates
                  if($block_id == 'postsmasonry1') {

                    // Posts Masonry 1
                    if($i == 1) {

                      echo '<div class="col-md-7">';

                      get_template_part( 'inc/templates/post/content', 'grid-large' );

                      echo '</div>';

                    } else {

                      echo '<div class="col-md-5">';

                      get_template_part( 'inc/templates/post/content', 'card-short' );

                      echo '</div>';
                    }

                  } elseif($block_id == 'postsmasonry2') {

                    // Posts Masonry 2
                    if($i == 1) {

                      echo '<div class="col-md-4">';

                      get_template_part( 'inc/templates/post/content', 'card' );

                      echo '</div>';

                    } elseif($i > 4) {

                      if($i == 5) {
                        echo '<div class="col-md-3">';
                      }

                      get_template_part( 'inc/templates/post/content', 'text' );

                      if($i == $posts_query->post_count) {
                        echo '</div>';
                      }

                    } else {

                      if($i == 2) {
                        echo '<div class="col-md-5">';
                      }

                      get_template_part( 'inc/templates/post/content', 'list-small' );

                      if($i == 4) {
                        echo '</div>';
                      }

                    }

                  } elseif($block_id == 'postsmasonry3') {

                    // Posts Masonry 3
                    if($i == 1) {

                      echo '<div class="col-md-5">';

                      get_template_part( 'inc/templates/post/content', 'grid-large' );

                      echo '</div>';

                    } else {

                      echo '<div class="col-md-7">';

                      get_template_part( 'inc/templates/post/content', 'list-medium' );

                      echo '</div>';
                    }

                  } elseif($block_id == 'showcase1') {

                    if(!isset($div_opened)) {
                      $div_opened = false;
                    }

                    // Showcase 1
                    if($i == 1) {

                      echo '<div class="col-md-3">';

                      get_template_part( 'inc/templates/post/content', 'overlay-short' );

                      $div_opened = true;

                    } elseif($i == 2) {

                      get_template_part( 'inc/templates/post/content', 'overlay-short' );

                      echo '</div>';

                      $div_opened = false;

                    } elseif($i == 3) {

                      echo '<div class="col-md-6">';

                      get_template_part( 'inc/templates/post/content', 'overlay' );

                      echo '</div>';

                    } elseif($i == 4) {

                      echo '<div class="col-md-3">';

                      get_template_part( 'inc/templates/post/content', 'overlay-short' );

                      $div_opened = true;

                    } else {

                      get_template_part( 'inc/templates/post/content', 'overlay-short' );

                      echo '</div>';

                      $div_opened = false;

                    }

                    if(($posts_query->post_count < $settings['block_posts_limit']) && $div_opened && ($i == $posts_query->post_count)) {
                      echo '</div>';
                    }

                  } elseif($block_id == 'showcase2') {

                    // Showcase 2
                    if($i == 1) {

                      echo '<div class="col-md-12">';

                      get_template_part( 'inc/templates/post/content', 'overlay-short' );

                      echo '</div>';

                    } else {

                      echo '<div class="col-md-4">';

                      get_template_part( 'inc/templates/post/content', 'overlay-short' );

                      echo '</div>';

                    }

                  } elseif($block_id == 'showcase3') {

                    // Showcase 3
                    if($i == 1) {

                      echo '<div class="col-md-6">';

                      get_template_part( 'inc/templates/post/content', 'overlay' );

                      echo '</div>';

                    } else {

                      echo '<div class="col-md-3">';

                      get_template_part( 'inc/templates/post/content', 'card-short' );

                      echo '</div>';

                    }
                  } elseif($block_id == 'showcase4') {

                     // Showcase 4
                    if($i == 1) {

                      echo '<div class="col-md-6">';

                      get_template_part( 'inc/templates/post/content', 'overlay' );

                      echo '</div>';

                    } elseif($i == 2) {

                      echo '<div class="col-md-6">';

                      get_template_part( 'inc/templates/post/content', 'overlay-short' );

                      $second_col = true;

                    } else {

                      get_template_part( 'inc/templates/post/content', 'overlay-short' );

                      if($i == $settings['block_posts_limit'] && $second_col) {
                        echo '</div>';
                      }
                    }

                    if(($posts_query->post_count < $settings['block_posts_limit']) && $second_col && ($i == $posts_query->post_count)) {
                      echo '</div>';
                    }
                  } elseif($block_id == 'showcase5') {

                    // Showcase 5
                    if(!isset($div_opened)) {
                      $div_opened = false;
                    }

                    // Showcase 1
                    if($i == 1) {

                      echo '<div class="col-md-3">';

                      get_template_part( 'inc/templates/post/content', 'grid-short' );

                      $div_opened = true;

                    } elseif($i == 2) {

                      get_template_part( 'inc/templates/post/content', 'grid-short' );

                      echo '</div>';

                      $div_opened = false;

                    } elseif($i == 3) {

                      echo '<div class="col-md-6">';

                      get_template_part( 'inc/templates/post/content', 'grid-large' );

                      echo '</div>';

                    } elseif($i == 4) {

                      echo '<div class="col-md-3">';

                      get_template_part( 'inc/templates/post/content', 'grid-short' );

                      $div_opened = true;

                    } else {

                      get_template_part( 'inc/templates/post/content', 'grid-short' );

                      echo '</div>';

                      $div_opened = false;

                    }

                    if(($posts_query->post_count < $settings['block_posts_limit']) && $div_opened && ($i == $posts_query->post_count)) {
                      echo '</div>';
                    }

                  } elseif($block_id == 'showcase6') {

                    if(!isset($div_opened)) {
                      $div_opened = false;
                    }

                    // Showcase 6
                    if($i == 1) {

                      echo '<div class="col-md-6">';

                      get_template_part( 'inc/templates/post/content', 'grid-large' );

                      echo '</div>';

                      $div_opened = false;

                    } elseif($i == 2) {

                      echo '<div class="col-md-3">';

                      get_template_part( 'inc/templates/post/content', 'grid-short' );

                      $div_opened = true;

                    } elseif($i == 3) {

                      get_template_part( 'inc/templates/post/content', 'grid-short' );

                      echo '</div>';

                      $div_opened = false;

                    } elseif($i == 4) {

                      echo '<div class="col-md-3">';

                      get_template_part( 'inc/templates/post/content', 'grid-short' );

                      $div_opened = true;

                    } else {

                      get_template_part( 'inc/templates/post/content', 'grid-short' );

                      echo '</div>';

                      $div_opened = false;

                    }

                    if(($posts_query->post_count < $settings['block_posts_limit']) && $div_opened && ($i == $posts_query->post_count)) {
                      echo '</div>';
                    }
                  // Grid templates
                  } elseif($block_id == 'postsgrid1') {

                    echo '<div class="'.esc_attr(davenport_get_postsgrid_col($block_id)).'">';

                    $post_template = 'card';

                    get_template_part( 'inc/templates/post/content', $post_template );

                    echo '</div>';

                  } elseif($block_id == 'postsgrid2') {

                    echo '<div class="'.esc_attr(davenport_get_postsgrid_col($block_id)).'">';

                    $post_template = 'overlay';

                    get_template_part( 'inc/templates/post/content', $post_template );

                    echo '</div>';

                  } elseif($block_id == 'postsgrid3') {

                    echo '<div class="'.esc_attr(davenport_get_postsgrid_col($block_id)).'">';

                    $post_template = 'overlay-short';

                    get_template_part( 'inc/templates/post/content', $post_template );

                    echo '</div>';

                  } elseif($block_id == 'postsgrid4') {

                    echo '<div class="'.esc_attr(davenport_get_postsgrid_col($block_id)).'">';

                    $post_template = 'grid-short';

                    get_template_part( 'inc/templates/post/content', $post_template );

                    echo '</div>';

                  } elseif($block_id == 'postsgrid5') {

                    echo '<div class="'.esc_attr(davenport_get_postsgrid_col($block_id)).'">';

                    $post_template = 'text';

                    get_template_part( 'inc/templates/post/content', $post_template );

                    echo '</div>';

                  } elseif($block_id == 'postsgrid6') {

                    echo '<div class="'.esc_attr(davenport_get_postsgrid_col($block_id)).'">';

                    $post_template = 'overlay-short';

                    get_template_part( 'inc/templates/post/content', $post_template );

                    echo '</div>';

                  } elseif($block_id == 'postsgrid7') {

                    echo '<div class="'.esc_attr(davenport_get_postsgrid_col($block_id)).'">';

                    $post_template = 'list-small';

                    get_template_part( 'inc/templates/post/content', $post_template );

                    echo '</div>';

                  } elseif($block_id == 'postsgrid8') {

                    echo '<div class="'.esc_attr(davenport_get_postsgrid_col($block_id)).'">';

                    $post_template = 'grid';

                    get_template_part( 'inc/templates/post/content', $post_template );

                    echo '</div>';

                  }
              }
            }

            if (  $posts_query->max_num_pages > 1 && $settings['block_posts_loadmore'] == 'yes' ) {
              echo '<div class="col-md-12 davenport-block-button"'.davenport_add_aos(false).'><a href="#" class="btn btn-load-more">'.esc_html__('Load more', 'davenport').'</a></div>';
            }

            wp_reset_postdata();

            echo '</div>';
            echo '</div>';

            echo '</div>';

            // Load more JS script
            if (  $posts_query->max_num_pages > 1 && $settings['block_posts_loadmore'] == 'yes' ) {
              wp_add_inline_script( 'davenport-script', "(function($){
              $(document).ready(function() {
                  'use strict';

                  var current_page_".esc_js($unique_block_id)." = 1;

                  $('.davenport-".esc_js($block_id)."-block-wrapper-".esc_js($unique_block_id)." .btn-load-more').on('click', function(e){

                    e.preventDefault();
                    e.stopPropagation();

                    var button = $(this),
                        data = {
                        'action': 'davenport_loadmore',
                        'query': ".json_encode( $posts_query->query_vars , true).",
                        'page' : current_page_".esc_js($unique_block_id).",
                        'block' : '".esc_js($block_id)."',
                        'post_template' : '".esc_js($post_template)."'
                    };

                    var button_default_text = button.text();

                    $.ajax({
                        url : '".esc_url(site_url())."/wp-admin/admin-ajax.php', // AJAX handler
                        data : data,
                        type : 'POST',
                        beforeSend : function ( xhr ) {
                            button.text('".esc_html__('Loading...', 'davenport')."');
                            button.addClass('btn-loading');
                        },
                        success : function( data ){
                            if( data ) {
                                button.text( button_default_text );
                                button.removeClass('btn-loading');

                                // Insert new posts
                                $('.davenport-".esc_js($block_id)."-block-wrapper-".esc_js($unique_block_id)." .davenport-block-button').before(data);

                                // Show images
                                $('.davenport-".esc_js($block_id)."-block-wrapper-".esc_js($unique_block_id)." .davenport-post-image').each(function( index ) {
                                  $(this).attr('style', ($(this).attr('data-style')));
                                });

                                // Show categories colors
                                $('.davenport-".esc_js($block_id)."-block-wrapper-".esc_js($unique_block_id)." .davenport-post .post-categories a').each(function( index ) {
                                  $(this).attr('style', ($(this).attr('data-style')));
                                });

                                // Show rating badges
                                $('.davenport-".esc_js($block_id)."-block-wrapper-".esc_js($unique_block_id)." .davenport-post .post-review-rating-badge').each(function( index ) {
                                  $(this).attr('style', ($(this).attr('data-style')));
                                });

                                current_page_".esc_js($unique_block_id)."++;

                                if ( current_page_".esc_js($unique_block_id)." == ".esc_js($posts_query->max_num_pages)." )
                                    button.remove(); // if last page, remove the button

                            } else {
                                button.remove(); // if no data, remove the button
                            }
                        }
                    });
                  });

              });})(jQuery);");

          }
}
endif;

/**
 * Posts Grid 1 block display
 */
if(!function_exists('davenport_block_postsgrid1_display')):
function davenport_block_postsgrid1_display($settings = '') {

  davenport_posts_block_renderer('postsgrid1', $settings);

}
endif;

/**
 * Posts Grid 2 block display
 */
if(!function_exists('davenport_block_postsgrid2_display')):
function davenport_block_postsgrid2_display($settings = '') {

  davenport_posts_block_renderer('postsgrid2', $settings);

}
endif;

/**
 * Posts Grid 3 block display
 */
if(!function_exists('davenport_block_postsgrid3_display')):
function davenport_block_postsgrid3_display($settings = '') {

  davenport_posts_block_renderer('postsgrid3', $settings);

}
endif;

/**
 * Posts Grid 4 block display
 */
if(!function_exists('davenport_block_postsgrid4_display')):
function davenport_block_postsgrid4_display($settings = '') {

  davenport_posts_block_renderer('postsgrid4', $settings);

}
endif;

/**
 * Posts Grid 5 block display
 */
if(!function_exists('davenport_block_postsgrid5_display')):
function davenport_block_postsgrid5_display($settings = '') {

  davenport_posts_block_renderer('postsgrid5', $settings);

}
endif;

/**
 * Posts Grid 6 block display
 */
if(!function_exists('davenport_block_postsgrid6_display')):
function davenport_block_postsgrid6_display($settings = '') {

  davenport_posts_block_renderer('postsgrid6', $settings);

}
endif;

/**
 * Posts Grid 7 block display
 */
if(!function_exists('davenport_block_postsgrid7_display')):
function davenport_block_postsgrid7_display($settings = '') {

  davenport_posts_block_renderer('postsgrid7', $settings);

}
endif;

/**
 * Posts Grid 8 block display
 */
if(!function_exists('davenport_block_postsgrid8_display')):
function davenport_block_postsgrid8_display($settings = '') {

  davenport_posts_block_renderer('postsgrid8', $settings);

}
endif;

/**
 * Posts Masonry 1 block display
 */
if(!function_exists('davenport_block_postsmasonry1_display')):
function davenport_block_postsmasonry1_display($settings = '') {

  $settings['block_posts_limit'] = 3;
  $settings['block_posts_loadmore'] = false;

  davenport_posts_block_renderer('postsmasonry1', $settings);

}
endif;

/**
 * Posts Masonry 2 block display
 */
if(!function_exists('davenport_block_postsmasonry2_display')):
function davenport_block_postsmasonry2_display($settings = '') {

  $settings['block_posts_limit'] = 8;
  $settings['block_posts_loadmore'] = false;

  davenport_posts_block_renderer('postsmasonry2', $settings);

}
endif;

/**
 * Posts Masonry 3 block display
 */
if(!function_exists('davenport_block_postsmasonry3_display')):
function davenport_block_postsmasonry3_display($settings = '') {

  $settings['block_posts_limit'] = 4;
  $settings['block_posts_loadmore'] = false;

  davenport_posts_block_renderer('postsmasonry3', $settings);

}
endif;

/**
 * Showcase 1 block display
 */
if(!function_exists('davenport_block_showcase1_display')):
function davenport_block_showcase1_display($settings = '') {

  $settings['block_posts_limit'] = 5;
  $settings['block_posts_loadmore'] = false;

  davenport_posts_block_renderer('showcase1', $settings);

}
endif;

/**
 * Showcase 2 block display
 */
if(!function_exists('davenport_block_showcase2_display')):
function davenport_block_showcase2_display($settings = '') {

  $settings['block_posts_limit'] = 5;
  $settings['block_posts_loadmore'] = false;

  davenport_posts_block_renderer('showcase2', $settings);

}
endif;

/**
 * Showcase 3 block display
 */
if(!function_exists('davenport_block_showcase3_display')):
function davenport_block_showcase3_display($settings = '') {

  $settings['block_posts_limit'] = 3;
  $settings['block_posts_loadmore'] = false;

  davenport_posts_block_renderer('showcase3', $settings);

}
endif;

/**
 * Showcase 4 block display
 */
if(!function_exists('davenport_block_showcase4_display')):
function davenport_block_showcase4_display($settings = '') {

  $settings['block_posts_limit'] = 3;
  $settings['block_posts_loadmore'] = false;

  davenport_posts_block_renderer('showcase4', $settings);

}
endif;

/**
 * Showcase 5 block display
 */
if(!function_exists('davenport_block_showcase5_display')):
function davenport_block_showcase5_display($settings = '') {

  $settings['block_posts_limit'] = 5;
  $settings['block_posts_loadmore'] = false;

  davenport_posts_block_renderer('showcase5', $settings);

}
endif;

/**
 * Showcase 6 block display
 */
if(!function_exists('davenport_block_showcase6_display')):
function davenport_block_showcase6_display($settings = '') {

  $settings['block_posts_limit'] = 5;
  $settings['block_posts_loadmore'] = false;

  davenport_posts_block_renderer('showcase6', $settings);

}
endif;

/**
 * Large Posts Slider block display
 */
if(!function_exists('davenport_block_largepostsslider_display')):
function davenport_block_largepostsslider_display($settings = '') {

  $args = davenport_get_wpquery_args($settings);

  $posts_query = new WP_Query;
  $posts = $posts_query->query($args);

  $total_posts = count($posts);

  if($posts_query->have_posts()) {

    $unique_block_id = rand(10000, 900000);
    ?>
    <div class="davenport-largepostsslider-block-wrapper">
      <div class="container">
        <div class="row">
          <div class="davenport-largepostsslider-block davenport-largepostsslider-block-<?php echo esc_attr($unique_block_id); ?> davenport-block">
            <div class="owl-carousel">
            <?php
            while ($posts_query->have_posts()) {
              $posts_query->the_post();

              echo '<div class="col-md-12">';

              get_template_part( 'inc/templates/post/content', 'overlay-short' );

              echo '</div>';
            }
            ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php
      if($total_posts > 1) {
        wp_add_inline_script( 'davenport-script', '(function($){
        $(document).ready(function() {

            var owlpostslider = $(".davenport-largepostsslider-block.davenport-largepostsslider-block-'.esc_js($unique_block_id).' .owl-carousel").owlCarousel({
                loop: true,
                items: 1,
                autoplay: true,
                autowidth: false,
                autoplaySpeed: 1000,
                navSpeed: 5000,
                nav: false,
                dots: false,
                navText: false,
                responsive: {
                    1199:{
                        items:1
                    },
                    979:{
                        items:1
                    },
                    768:{
                        items:1
                    },
                    479:{
                        items:1
                    },
                    0:{
                        items:1
                    }
                }
            });

            AOS.refresh();

        });})(jQuery);');
      } else {
        wp_add_inline_script( 'davenport-script', '(function($){
            $(document).ready(function() {

              "use strict";

               $(".davenport-largepostsslider-block.davenport-largepostsslider-block-'.esc_js($unique_block_id).' .owl-carousel").show();

               AOS.refresh();

            });})(jQuery);');
      }

    } // have_posts

}
endif;

/**
 * Posts Carousel block display
 */
if(!function_exists('davenport_block_carousel_display')):
function davenport_block_carousel_display($settings = '') {

  $args = davenport_get_wpquery_args($settings);

  $posts_query = new WP_Query;
  $posts = $posts_query->query($args);

  $total_posts = count($posts);

  if($posts_query->have_posts()) {

    $unique_block_id = rand(10000, 900000);
    ?>
    <div class="davenport-carousel-block-wrapper davenport-block">
      <?php
      if(!empty($settings['block_title'])) {
        echo '<div class="container container-title">';
        echo '<div class="row">';
        echo '<div class="davenport-block-title">';
        echo '<h3>'.esc_html($settings['block_title']).'</h3>';
        if(!empty($settings['block_subtitle'])) {
          echo '<h4>'.esc_html($settings['block_subtitle']).'</h4>';
        }
        echo '</div>';
        echo '</div>';
        echo '</div>';
      }
      ?>
      <div class="container container-content">
        <div class="row">
          <div class="davenport-carousel-block davenport-carousel-block-<?php echo esc_attr($unique_block_id); ?> davenport-block">
            <div class="davenport-carousel-block-inside">
              <div class="owl-carousel">
              <?php
              while ($posts_query->have_posts()) {
                $posts_query->the_post();

                get_template_part( 'inc/templates/post/content', 'grid-short' );

              }
              ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php
      if($total_posts > 1) {
        wp_add_inline_script( 'davenport-script', '(function($){
        $(document).ready(function() {

            var owlpostslider = $(".davenport-carousel-block.davenport-carousel-block-'.esc_js($unique_block_id).' .owl-carousel").owlCarousel({
                loop: true,
                items: 4,
                autoplay: true,
                autowidth: false,
                autoplaySpeed: 500,
                navSpeed: 500,
                margin: 30,
                nav: false,
                dots: false,
                navText: false,
                slideBy: 4,
                responsive: {
                    1199:{
                        items:4,
                        slideBy: 4
                    },
                    979:{
                        items:4,
                        slideBy: 4
                    },
                    768:{
                        items:2,
                        slideBy: 1
                    },
                    479:{
                        items:1,
                        slideBy: 1
                    },
                    0:{
                        items:1,
                        slideBy: 1
                    }
                }
            });

            AOS.refresh();

        });})(jQuery);');
      } else {
        wp_add_inline_script( 'davenport-script', '(function($){
            $(document).ready(function() {

              "use strict";

               $(".davenport-carousel-block.davenport-carousel-block-'.esc_js($unique_block_id).' .owl-carousel").show();

               AOS.refresh();

            });})(jQuery);');
      }

    } // have_posts

}
endif;

/**
 * Posts Carousel 2 block display
 */
if(!function_exists('davenport_block_carousel2_display')):
function davenport_block_carousel2_display($settings = '') {

  $args = davenport_get_wpquery_args($settings);

  $posts_query = new WP_Query;
  $posts = $posts_query->query($args);

  $total_posts = count($posts);

  if($posts_query->have_posts()) {

    $unique_block_id = rand(10000, 900000);
    ?>
    <div class="davenport-carousel2-block-wrapper davenport-block">
      <?php
      if(!empty($settings['block_title'])) {
        echo '<div class="container container-title">';
        echo '<div class="row">';
        echo '<div class="davenport-block-title">';
        echo '<h3>'.esc_html($settings['block_title']).'</h3>';
        if(!empty($settings['block_subtitle'])) {
          echo '<h4>'.esc_html($settings['block_subtitle']).'</h4>';
        }
        echo '</div>';
        echo '</div>';
        echo '</div>';
      }
      ?>
      <div class="container container-content">
        <div class="row">
          <div class="davenport-carousel-block davenport-carousel-block-<?php echo esc_attr($unique_block_id); ?> davenport-block">
            <div class="davenport-carousel-block-inside">
              <div class="owl-carousel">
              <?php
              while ($posts_query->have_posts()) {
                $posts_query->the_post();

                get_template_part( 'inc/templates/post/content', 'card-short' );

              }
              ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php
      if($total_posts > 1) {
        wp_add_inline_script( 'davenport-script', '(function($){
        $(document).ready(function() {

            var owlpostslider = $(".davenport-carousel-block.davenport-carousel-block-'.esc_js($unique_block_id).' .owl-carousel").owlCarousel({
                loop: true,
                items: 5,
                autoplay: true,
                autowidth: false,
                autoplaySpeed: 500,
                navSpeed: 500,
                margin: 0,
                nav: false,
                dots: false,
                navText: false,
                slideBy: 1,
                responsive: {
                    1199:{
                        items: 5,
                        slideBy: 1
                    },
                    979:{
                        items: 3,
                        slideBy: 1
                    },
                    768:{
                        items:2,
                        slideBy: 1
                    },
                    479:{
                        items:1,
                        slideBy: 1
                    },
                    0:{
                        items:1,
                        slideBy: 1
                    }
                }
            });

            AOS.refresh();

        });})(jQuery);');
      } else {
        wp_add_inline_script( 'davenport-script', '(function($){
            $(document).ready(function() {

              "use strict";

               $(".davenport-carousel-block.davenport-carousel-block-'.esc_js($unique_block_id).' .owl-carousel").show();

               AOS.refresh();

            });})(jQuery);');
      }

    } // have_posts

}
endif;

/**
 * Fullwidth Posts Slider block display
 */
if(!function_exists('davenport_block_fullwidthpostsslider_display')):
function davenport_block_fullwidthpostsslider_display($settings = '') {

  $args = davenport_get_wpquery_args($settings);

  $posts_query = new WP_Query;
  $posts = $posts_query->query($args);

  $total_posts = count($posts);

  if($posts_query->have_posts()) {

    $unique_block_id = rand(10000, 900000);
    ?>
    <div class="davenport-fullwidthpostsslider-block-wrapper davenport-block">
      <?php
      if(!empty($settings['block_title'])) {
        echo '<div class="container container-title">';
        echo '<div class="row">';
        echo '<div class="davenport-block-title">';
        echo '<h3>'.esc_html($settings['block_title']).'</h3>';
        if(!empty($settings['block_subtitle'])) {
          echo '<h4>'.esc_html($settings['block_subtitle']).'</h4>';
        }
        echo '</div>';
        echo '</div>';
        echo '</div>';
      }
      ?>
      <div class="container-fluid">
        <div class="row">
          <div class="davenport-fullwidthpostsslider-block davenport-fullwidthpostsslider-block-<?php echo esc_attr($unique_block_id); ?> davenport-block">
            <div class="owl-carousel">
            <?php
            while ($posts_query->have_posts()) {
              $posts_query->the_post();

              echo '<div class="col-md-12">';

              get_template_part( 'inc/templates/post/content', 'overlay-short' );

              echo '</div>';
            }
            ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php
      if($total_posts > 1) {
        wp_add_inline_script( 'davenport-script', '(function($){
        $(document).ready(function() {

            "use strict";

            var owlpostslider = $(".davenport-fullwidthpostsslider-block.davenport-fullwidthpostsslider-block-'.esc_js($unique_block_id).' .owl-carousel").owlCarousel({
                loop: true,
                items: 1,
                autoplay: true,
                autowidth: false,
                autoplaySpeed: 1000,
                navSpeed: 5000,
                nav: false,
                dots: false,
                navText: false,
                responsive: {
                    1199:{
                        items:1
                    },
                    979:{
                        items:1
                    },
                    768:{
                        items:1
                    },
                    479:{
                        items:1
                    },
                    0:{
                        items:1
                    }
                }
            });

            AOS.refresh();

        });})(jQuery);');
      } else {
        wp_add_inline_script( 'davenport-script', '(function($){
            $(document).ready(function() {

               "use strict";

               $(".davenport-fullwidthpostsslider-block.davenport-fullwidthpostsslider-block-'.esc_js($unique_block_id).' .owl-carousel").show();

               AOS.refresh();

            });})(jQuery);');
      }

    } // have_posts

}
endif;

/**
 * Post Highlight block display
 */
if(!function_exists('davenport_block_posthighlight_display')):
function davenport_block_posthighlight_display($settings = '') {

  $args = davenport_get_wpquery_args($settings);

  $posts_query = new WP_Query;
  $posts = $posts_query->query($args);

  $total_posts = $posts_query->post_count;

  if($posts_query->have_posts()) {

    $unique_block_id = rand(10000, 900000);
    ?>
    <div class="davenport-posthighlight-block-wrapper davenport-block">
      <div class="container">
        <div class="row">
          <?php
          if(!empty($settings['block_title'])) {
            echo '<div class="davenport-block-title">';
            echo '<h3>'.esc_html($settings['block_title']).'</h3>';
            if(!empty($settings['block_subtitle'])) {
              echo '<h4>'.esc_html($settings['block_subtitle']).'</h4>';
            }
            echo '</div>';
          }
          ?>
          <div class="davenport-posthighlight-block davenport-posthighlight-block-<?php echo esc_attr($unique_block_id); ?> davenport-block owl-carousel">
            <?php
            while ($posts_query->have_posts()) {

              $posts_query->the_post();

              $post = get_post();

              if (has_post_thumbnail($post->ID)) {
                  $image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'davenport-blog-thumb-grid');
                  $image_bg ='background-image: url('.esc_url($image[0]).');';
              } else {
                  $image_bg = '';
              }

              $current_post_format = get_post_format($post->ID) ? get_post_format($post->ID) : 'standard';
              $post_format_icon = '';

              if (in_array($current_post_format, davenport_get_mediaformats())) {
                  $post_format_icon = '<div class="davenport-post-format-icon"></div>';
              }

              echo '<div class="davenport-posthighlight-slide">';

              echo '<div class="col-md-6 davenport-posthighlight-block-left">';

              get_template_part( 'inc/templates/post/content', 'text-large' );

              echo '</div>';

              echo '<div class="col-md-6 davenport-posthighlight-block-right">';

              echo '<div class="davenport-post"><div class="davenport-post-image-wrapper davenport-posthighlight-image"><div class="davenport-post-image" data-style="'.esc_attr($image_bg).'">'.wp_kses_post($post_format_icon).'</div></div></div>';

              get_template_part( 'inc/templates/post/content', 'card' );

              echo '</div>';

              echo '</div>';
            }

            if($total_posts > 1) {
              wp_add_inline_script( 'davenport-script', '(function($){
              $(document).ready(function() {

                  "use strict";

                  var owlpostslider = $(".davenport-posthighlight-block.davenport-posthighlight-block-'.esc_js($unique_block_id).'.owl-carousel").owlCarousel({
                      loop: true,
                      items: 1,
                      autoplay: true,
                      autowidth: false,
                      autoplaySpeed: 1000,
                      navSpeed: 5000,
                      nav: false,
                      dots: true,
                      navText: false,
                      responsive: {
                          1199:{
                              items:1
                          },
                          979:{
                              items:1
                          },
                          768:{
                              items:1
                          },
                          479:{
                              items:1
                          },
                          0:{
                              items:1
                          }
                      }
                  });

                  AOS.refresh();

              });})(jQuery);');
            } else {
              wp_add_inline_script( 'davenport-script', '(function($){
                  $(document).ready(function() {

                     "use strict";

                     $(".davenport-posthighlight-block.davenport-posthighlight-block-'.esc_js($unique_block_id).'.owl-carousel").show();

                     AOS.refresh();

                  });})(jQuery);');
            }
            ?>
          </div>
        </div>
      </div>
    </div>
    <?php

    } // have_posts

}
endif;

/**
 * Content block display
 */
if(!function_exists('davenport_block_html_display')):
function davenport_block_html_display($settings = '') {
  ?>
  <div class="container html-block-container davenport-block"<?php davenport_add_aos(); ?>>
    <div class="row">
      <?php
      if(!empty($settings['block_title'])) {
        echo '<div class="davenport-block-title">';
        echo '<h3>'.esc_html($settings['block_title']).'</h3>';
        if(!empty($settings['block_subtitle'])) {
          echo '<h4>'.esc_html($settings['block_subtitle']).'</h4>';
        }
        echo '</div>';
      }
      ?>
      <div class="col-md-12 html-block"><?php echo do_shortcode($settings['block_html']); ?></div>
    </div>
  </div>
  <?php
}
endif;

/**
 * Blog listing display
 */
if(!function_exists('davenport_block_blog_display')):
function davenport_block_blog_display($settings = '') {

  $blog_sidebarposition = get_theme_mod('sidebar_blog', 'right');

  // Demo settings
  if ( defined('DEMO_MODE') && isset($_GET['blog_sidebar_position']) ) {
    $blog_sidebarposition = $_GET['blog_sidebar_position'];
  }

  if(is_active_sidebar( 'main-sidebar' ) && ($blog_sidebarposition !== 'disable') ) {
    $span_class = 'col-md-8';
    $is_sidebar = true;
  }
  else {
    $span_class = 'col-md-12';
    $is_sidebar = false;
  }

  // Blog layout
  $blog_layout = get_theme_mod('blog_layout', 'standard');

  if ( defined('DEMO_MODE') && isset($_GET['blog_layout']) ) {
      $blog_layout = $_GET['blog_layout'];
  }

  // Load masonry layout script
  if($blog_layout == 'masonry') {

    wp_enqueue_script('masonry');
    wp_add_inline_script( 'masonry', '(function($){
  $(document).ready(function() {
    "use strict";
    $(window).load(function()
    {
      var $container = $(".blog-layout-masonry");

      $container.imagesLoaded(function(){
        $container.masonry({
          itemSelector : ".blog-layout-masonry .blog-post"
        });

      });

      AOS.refresh();
    });

  });})(jQuery);');

  }

  ?>
  <div class="davenport-blog-block-wrapper page-container container">
    <div class="row">
      <?php if ( is_active_sidebar( 'main-sidebar' ) && ( $blog_sidebarposition == 'left')) : ?>
      <div class="col-md-4 main-sidebar sidebar sidebar-left"<?php davenport_add_aos(true);?> role="complementary">
      <ul id="main-sidebar">
        <?php dynamic_sidebar( 'main-sidebar' ); ?>
      </ul>
      </div>
      <?php endif; ?>

      <div class="<?php echo esc_attr($span_class);?>">
      <?php
      if(!empty($settings['block_title'])) {
        echo '<div class="davenport-blog-block-title-wrapper davenport-block">';
        echo '<div class="davenport-block-title">';
        echo '<h3>'.esc_html($settings['block_title']).'</h3>';
        if(!empty($settings['block_subtitle'])) {
          echo '<h4>'.esc_html($settings['block_subtitle']).'</h4>';
        }
        echo '</div>';
        echo '</div>';
      }
      ?>
      <div class="blog-posts-list blog-layout-<?php echo esc_attr($blog_layout);?><?php echo esc_attr(davenport_get_blog_col_class($blog_layout, $is_sidebar));?>" id="content">
      <?php

      // Blog listing settings
      $settings['block_posts_limit'] = get_option( 'posts_per_page' );
      $settings['block_posts_type'] = 'latest';

      $args = davenport_get_wpquery_args($settings);

      $posts_query = new WP_Query;
      $posts = $posts_query->query($args);

      $wp_query = $posts_query;

      ?>
      <?php if ( have_posts() ) : ?>

        <?php /* Start the Loop */
        $post_loop_id = 1;
        ?>
        <?php while ( have_posts() ) : the_post(); ?>

        <?php
          $post_loop_details['post_loop_id'] = $post_loop_id;
          $post_loop_details['span_class'] = $span_class;

          davenport_set_post_details($post_loop_details);

          get_template_part( 'content', get_post_format() );

          $post_loop_id++;
        ?>

        <?php endwhile; ?>

      <?php else : ?>

        <?php get_template_part( 'no-results', 'index' ); ?>

      <?php endif; ?>
      </div>

      <?php
      // Load more
      if ( $wp_query->max_num_pages > 1 && isset($settings['block_posts_loadmore']) && $settings['block_posts_loadmore'] == 'yes' && $blog_layout !== 'masonry' && !is_paged() ) {
        echo '<div class="col-md-12 davenport-block-button"'.davenport_add_aos(false).'><a href="#" class="btn btn-load-more">'.esc_html__('Load more', 'davenport').'</a></div>';
      } else {
        davenport_content_nav( 'nav-below' );
      }
      ?>

      <?php
      // Post Loops Bottom Banner
      davenport_banner_display('posts_loop_bottom');
      ?>

      </div>

      <?php if ( is_active_sidebar( 'main-sidebar' ) && ( $blog_sidebarposition == 'right')) : ?>
      <div class="col-md-4 main-sidebar sidebar sidebar-right"<?php davenport_add_aos(true);?> role="complementary">
      <ul id="main-sidebar">
        <?php dynamic_sidebar( 'main-sidebar' ); ?>
      </ul>
      </div>
      <?php endif; ?>
    </div>
  </div>
  <?php

  // Load more JS script
  if ( $wp_query->max_num_pages > 1 && isset($settings['block_posts_loadmore']) && $settings['block_posts_loadmore'] == 'yes' ) {

    $post_template = 'blog';

    wp_add_inline_script( 'davenport-script', "(function($){
    $(document).ready(function() {
        'use strict';

        var current_page = 1;

        $('.blog-posts-list + .davenport-block-button .btn-load-more').on('click', function(e){

          e.preventDefault();
          e.stopPropagation();

          var button = $(this),
              data = {
              'action': 'davenport_loadmore',
              'query': ".json_encode( $wp_query->query_vars , true).",
              'page' : current_page,
              'block' : 'blog',
              'post_template' : '".esc_js($post_template)."'
          };

          var button_default_text = button.text();

          $.ajax({
              url : '".esc_url(site_url())."/wp-admin/admin-ajax.php', // AJAX handler
              data : data,
              type : 'POST',
              beforeSend : function ( xhr ) {
                  button.text('".esc_html__('Loading...', 'davenport')."');
                  button.addClass('btn-loading');
              },
              success : function( data ){
                  if( data ) {
                      button.text( button_default_text );
                      button.removeClass('btn-loading');

                      // Insert new posts
                      $('.blog-posts-list').append(data);

                      // Show images
                      $('.blog-posts-list .davenport-post-image').each(function( index ) {
                        $(this).attr('style', ($(this).attr('data-style')));
                      });

                      // Show categories colors
                      $('.blog-posts-list .davenport-post .post-categories a').each(function( index ) {
                        $(this).attr('style', ($(this).attr('data-style')));
                      });

                      // Show rating badges
                      $('.blog-posts-list .davenport-post .post-review-rating-badge').each(function( index ) {
                        $(this).attr('style', ($(this).attr('data-style')));
                      });

                      current_page++;

                      if ( current_page == ".esc_js($wp_query->max_num_pages)." )
                          button.parent().remove(); // if last page, remove the button

                  } else {
                      button.parent().remove(); // if no data, remove the button
                  }
              }
          });
        });

    });})(jQuery);");

}
}
endif;

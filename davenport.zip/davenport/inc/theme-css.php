<?php
/**
 * Theme CSS cache generation
 */

	add_action( 'wp_enqueue_scripts', 'davenport_enqueue_dynamic_styles', '999' );
    add_action( 'admin_init', 'davenport_enqueue_editor_dynamic_styles', '999' );

    if(!function_exists('davenport_enqueue_editor_dynamic_styles')):
    function davenport_enqueue_editor_dynamic_styles( ) {
        // Fonts configuration for editor
        $headers_font = davenport_get_fonts_settings('headers_font');
        $body_font = davenport_get_fonts_settings('body_font');
        $additional_font = davenport_get_fonts_settings('additional_font');

        require_once(ABSPATH . 'wp-admin/includes/file.php'); // required to use WP_Filesystem();

        WP_Filesystem();

        global $wp_filesystem;

        $editor_cache_file_name = 'style-editor-cache-'.wp_get_theme()->get('TextDomain');

        $wp_upload_dir = wp_upload_dir();

        // Editor CSS cache files
        $css_editor_cache_file = $wp_upload_dir['basedir'].'/'.$editor_cache_file_name.'.css';
        $css_editor_cache_file_url = $wp_upload_dir['baseurl'].'/'.$editor_cache_file_name.'.css';

        $themeoptions_saved_date = get_option( 'themeoptions_saved_date', 1 );
        $editor_cache_saved_date = get_option( 'editor_cache_css_saved_date', 0 );

        // Check if editor CSS cache files exists
        if( file_exists( $css_editor_cache_file ) ) {
            $editor_cache_status = 'exist';

            if($themeoptions_saved_date > $editor_cache_saved_date) {
                $editor_cache_status = 'no-exist';
            }

        } else {
            $editor_cache_status = 'no-exist';
        }

        // FS_CHMOD_FILE required by WordPress guideliness - https://codex.wordpress.org/Filesystem_API#Using_the_WP_Filesystem_Base_Class
        if ( defined( 'FS_CHMOD_FILE' ) ) {
            $chmod_file = FS_CHMOD_FILE;
        } else {
            $chmod_file = ( 0644 & ~ umask() );
        }

        // Editor styles
        if ( $editor_cache_status !== 'exist' ) {

            $out = '/* Editor Cache file created at '.date('Y-m-d H:i:s').' */';

            $out .= '
                body {
                    font-family: "'.esc_attr($body_font['font-family']).'";
                    font-size: "'.esc_attr($body_font['font-size']).'";
                    color: "'.get_theme_mod('color_text', '#333333').'";
                }
                h1,
                h2,
                h3,
                h4,
                h5,
                h6,
                blockquote,
                .wp-block-quote,
                .wp-block-quote:not(.is-large):not(.is-style-large),
                blockquote cite,
                .wp-block-quote .wp-block-quote__citation,
                .editor-post-title__block .editor-post-title__input {
                    font-family: "'.esc_attr($headers_font['font-family']).'";
                }
                .wp-block-button {
                    font-family: "'.esc_attr($additional_font['font-family']).'";
                }
            ';

            // Small page width support
            if(get_theme_mod('blog_post_smallwidth', false)) {
                $out .= '.wp-block {
                    max-width: 880px;
                }
                ';
            }

            // Drop caps support
            if(get_theme_mod('blog_post_dropcaps', false)) {
                $out .= '.wp-block.editor-block-list__block:first-child p.wp-block-paragraph:first-child:first-letter {
                    float: left;
                    color: #000000;
                    font-size: 78px;
                    line-height: 60px;
                    padding-top: 10px;
                    padding-right: 10px;
                    padding-left: 0px;
                    font-weight: normal;
                    font-style: normal;
                }
                ';
            }

            $out = str_replace( array( "\t", "
", "\n", "  ", "   ", ), array( "", "", " ", " ", " ", ), $out );

            $wp_filesystem->put_contents( $css_editor_cache_file, $out, $chmod_file );

            // Update save options date
            $option_name = 'editor_cache_css_saved_date';

            $new_value = microtime(true) ;

            update_option( $option_name, $new_value, 'no' );
        }
    }
    endif;

    if(!function_exists('davenport_enqueue_dynamic_styles')):
	function davenport_enqueue_dynamic_styles( ) {

        // Fonts configuration for editor
        $headers_font = davenport_get_fonts_settings('headers_font');
        $body_font = davenport_get_fonts_settings('body_font');
        $additional_font = davenport_get_fonts_settings('additional_font');

        require_once(ABSPATH . 'wp-admin/includes/file.php'); // required to use WP_Filesystem();

        WP_Filesystem();

        global $wp_filesystem;

		if ( function_exists( 'is_multisite' ) && is_multisite() ){
            $cache_file_name = 'style-cache-'.wp_get_theme()->get('TextDomain').'-b' . get_current_blog_id();
        } else {
            $cache_file_name = 'style-cache-'.wp_get_theme()->get('TextDomain');
        }

        // Customizer preview
        if(is_customize_preview()) {
            if ( function_exists( 'is_multisite' ) && is_multisite() ){
                $cache_file_name = 'preview-cache-'.wp_get_theme()->get('TextDomain').'-b' . get_current_blog_id();
            } else {
                $cache_file_name = 'preview-cache-'.wp_get_theme()->get('TextDomain');
            }
        }

        $wp_upload_dir = wp_upload_dir();

        // Frontend CSS cache files
        $css_cache_file = $wp_upload_dir['basedir'].'/'.$cache_file_name.'.css';
        $css_cache_file_url = $wp_upload_dir['baseurl'].'/'.$cache_file_name.'.css';

        $themeoptions_saved_date = get_option( 'themeoptions_saved_date', 1 );
        $cache_saved_date = get_option( 'cache_css_saved_date', 0 );

        // Check if frontend cache files exists
		if( file_exists( $css_cache_file ) ) {
			$cache_status = 'exist';

            if($themeoptions_saved_date > $cache_saved_date) {
                $cache_status = 'no-exist';
            }

		} else {
			$cache_status = 'no-exist';
		}

        if ( defined('DEMO_MODE') ) {
            $cache_status = 'no-exist';
        }

        if(is_customize_preview()) {
            $cache_status = 'no-exist';
        }

        // FS_CHMOD_FILE required by WordPress guideliness - https://codex.wordpress.org/Filesystem_API#Using_the_WP_Filesystem_Base_Class
        if ( defined( 'FS_CHMOD_FILE' ) ) {
            $chmod_file = FS_CHMOD_FILE;
        } else {
            $chmod_file = ( 0644 & ~ umask() );
        }

        // Frontend styles
		if ( $cache_status == 'exist' ) {

			wp_register_style( $cache_file_name, $css_cache_file_url, array(), $cache_saved_date);
			wp_enqueue_style( $cache_file_name );

		} else {

			$out = '/* Cache file created at '.date('Y-m-d H:i:s').' */';

			$generated = microtime(true);

			$out .= davenport_get_css();

			$out = str_replace( array( "\t", "
", "\n", "  ", "   ", ), array( "", "", " ", " ", " ", ), $out );

			$out .= '/* CSS Generator Execution Time: ' . floatval( ( microtime(true) - $generated ) ) . ' seconds */';

			if ( $wp_filesystem->put_contents( $css_cache_file, $out, $chmod_file) ) {

				wp_register_style( $cache_file_name, $css_cache_file_url, array(), $cache_saved_date);
				wp_enqueue_style( $cache_file_name );

                // Update save options date
                update_option( 'cache_css_saved_date', microtime(true), 'no' );
			}

		}
	}
    endif;

    if(!function_exists('davenport_get_css')):
	function davenport_get_css() {

        // Fonts configuration for frontend
        $headers_font = davenport_get_fonts_settings('headers_font');
        $body_font = davenport_get_fonts_settings('body_font');
        $additional_font = davenport_get_fonts_settings('additional_font');

		// ===
		ob_start();
    ?>
    <?php
    // THEME OPTIONS DEFAULTS FOR CSS

    // Header height
    $header_height = get_theme_mod('header_height', 125);

    // Logo width
    $logo_width = get_theme_mod( 'logo_width', 257 );

    // Slider height
    $slider_height = get_theme_mod('slider_height', 420);

    // Main Menu paddings
    $mainmenu_paddings = get_theme_mod('mainmenu_paddings', '20px');

    // Top Menu paddings
    $topmenu_paddings = get_theme_mod('topmenu_paddings', '10px');

    // Thumbs height proportion
    $thumb_height_proportion = get_theme_mod('thumb_height_proportion', 64.8648);

    ?>
    header .col-md-12 {
        height: <?php echo esc_attr($header_height); ?>px;
    }
    .navbar .nav > li {
        padding-top: <?php echo esc_attr($mainmenu_paddings); ?>;
        padding-bottom: <?php echo esc_attr($mainmenu_paddings); ?>;
    }
    .nav > li > .sub-menu {
        margin-top: <?php echo esc_attr($mainmenu_paddings); ?>;
    }
    .header-menu li a,
    .header-menu .menu-top-menu-container-toggle {
        padding-top: <?php echo esc_attr($topmenu_paddings); ?>;
        padding-bottom: <?php echo esc_attr($topmenu_paddings); ?>;
    }
    .header-menu .menu-top-menu-container-toggle + div {
        top: calc(<?php echo esc_attr($topmenu_paddings); ?> + <?php echo esc_attr($topmenu_paddings); ?> + 20px);
    }
    <?php
    // Hide post dates
    if(get_theme_mod('blog_posts_date_hide', false)): ?>
    .davenport-post .post-date,
    .davenport-post .post-author:after,
    .davenport-post .post-author + .post-date,
    .sidebar .widget .post-date,
    .sidebar .widget .post-author + .post-date {
        display: none;
    }
    <?php endif; ?>
    <?php
    // Retina logo
    ?>
    header .logo-link img {
        width: <?php echo esc_attr($logo_width); ?>px;
    }
    .davenport-blog-posts-slider .davenport-post {
        height: <?php echo esc_attr($slider_height); ?>px;
    }
    .davenport-blog-posts-slider {
        max-height: <?php echo esc_attr($slider_height); ?>px;
    }
    <?php
    // Transparent header adjustments
    ?>
    @media (min-width: 1024px)  {
        body.single-post.blog-post-header-with-bg.blog-post-transparent-header-enable .container-page-item-title.with-bg .page-item-title-single,
        body.page.blog-post-header-with-bg.blog-post-transparent-header-enable .container-page-item-title.with-bg .page-item-title-single {
            padding-top: <?php echo intval(120 + $header_height); ?>px;
        }
    }
    <?php
    // Thumb height
    ?>
    .davenport-post .davenport-post-image-wrapper {
        padding-bottom: <?php echo esc_attr($thumb_height_proportion); ?>%;
    }
    <?php
    // Header topline
    if(get_theme_mod('header_topline', false)):

    $header_topline_bgcolor_1 = get_theme_mod('header_topline_bgcolor_1', '#22334C');
    $header_topline_bgcolor_2 = get_theme_mod('header_topline_bgcolor_2', '#E58477');

    ?>
    .header-topline-wrapper {
        background-color: <?php echo esc_attr($header_topline_bgcolor_1); ?>;
        background: -moz-linear-gradient(left,  <?php echo esc_attr($header_topline_bgcolor_1); ?> 0%, <?php echo esc_attr($header_topline_bgcolor_2); ?> 100%);
        background: -webkit-linear-gradient(left,  <?php echo esc_attr($header_topline_bgcolor_1); ?> 0%, <?php echo esc_attr($header_topline_bgcolor_2); ?> 100%);
        background: linear-gradient(to right,  <?php echo esc_attr($header_topline_bgcolor_1); ?> 0%, <?php echo esc_attr($header_topline_bgcolor_2); ?> 100%);
    }
    <?php endif;
    ?>
    /* Top menu */
    <?php if(get_theme_mod('topmenu_disable_mobile', true)): ?>
    @media (max-width: 991px) {
        .header-menu-bg {
            display: none;
        }
    }
    <?php endif; ?>
    /**
    * Theme Google Fonts
    **/
    <?php
    // Logo text font
    if ( get_theme_mod( 'logo_text', true ) == true && get_theme_mod( 'logo_text_title', '' ) !== '' ) {

    $logo_text_font = get_theme_mod( 'logo_text_font', array(
        'font-family'    => 'Cormorant Garamond',
        'font-size'    => '62px',
        'variant'        => 'regular',
        'color'          => '#000000',
    ));

    ?>
        header .logo-link.logo-text {
            font-family: '<?php echo esc_attr($logo_text_font['font-family']); ?>';
            <?php echo esc_attr(davenport_get_font_style_css($logo_text_font['variant'])); ?>
            font-size: <?php echo esc_attr($logo_text_font['font-size']); ?>;
            color: <?php echo esc_attr($logo_text_font['color']); ?>;
        }
        <?php
    }

    ?>
    .headers-font,
    h1, h2, h3, h4, h5, h6,
    .h1, .h2, .h3, .h4, .h5, .h6,
    .blog-post .format-quote .entry-content,
    blockquote,
    .sidebar .widget .post-title,
    .author-bio strong,
    .navigation-post .nav-post-name,
    .sidebar .widgettitle,
    .post-worthreading-post-container .post-worthreading-post-title,
    .post-worthreading-post-wrapper .post-worthreading-post-button,
    .navigation-post .nav-post-button-title,
    .page-item-title-archive .page-description,
    .sidebar .widget.widget_davenport_categories,
    .sidebar .widget.widget_nav_menu li,
    .davenport-featured-categories-wrapper .davenport-featured-category .davenport-featured-category-link {
        font-family: '<?php echo esc_attr($headers_font['font-family']); ?>';
        <?php echo esc_attr(davenport_get_font_style_css($headers_font['variant'])); ?>
    }
    body {
        font-family: '<?php echo esc_attr($body_font['font-family']); ?>';
        <?php echo esc_attr(davenport_get_font_style_css($body_font['variant'])); ?>
        font-size: <?php echo esc_attr($body_font['font-size']); ?>;
    }
    .additional-font,
    .btn,
    input[type="submit"],
    .woocommerce #content input.button,
    .woocommerce #respond input#submit,
    .woocommerce a.button,
    .woocommerce button.button,
    .woocommerce input.button,
    .woocommerce-page #content input.button,
    .woocommerce-page #respond input#submit,
    .woocommerce-page a.button,
    .woocommerce-page button.button,
    .woocommerce-page input.button,
    .woocommerce a.added_to_cart,
    .woocommerce-page a.added_to_cart,
    .woocommerce span.onsale,
    .woocommerce ul.products li.product .onsale,
    .wp-block-button a.wp-block-button__link,
    .header-menu,
    .mainmenu li.menu-item > a,
    .footer-menu,
    .davenport-post .post-categories,
    .sidebar .widget .post-categories,
    .page-item-title-archive .category-posts-count,
    .blog-post .post-categories,
    .davenport-blog-posts-slider .davenport-post-details .davenport-post-info,
    .post-subtitle-container,
    .sidebar .widget .post-date,
    .sidebar .widget .post-author,
    .davenport-post .post-author,
    .davenport-post .post-date,
    .davenport-post .post-details-bottom,
    .blog-post .tags,
    .navigation-post .nav-post-title,
    .comment-metadata .date,
    header .header-blog-info,
    .davenport-subscribe-block h6,
    .header-topline-wrapper .header-topline {
        font-family: '<?php echo esc_attr($additional_font['font-family']); ?>';
        <?php echo esc_attr(davenport_get_font_style_css($additional_font['variant'])); ?>
    }

    /**
    * Colors and color skins
    */
    <?php

    // Dark theme option
    if(get_theme_mod('color_darktheme', false)) {

        // Dark theme Custom CSS
        ?>
        /* Grey border */
        .davenport-postline-block,
        .davenport-post .post-details-bottom .post-info-wrapper,
        .davenport-post .post-details-bottom,
        .davenport-subscribe-block,
        .sidebar .widgettitle,
        header .social-icons-wrapper + .search-toggle-wrapper a.search-toggle-btn,
        .mainmenu-mobile-toggle i,
        .nav > li .sub-menu,
        .navigation-post:before,
        .comment-list li.comment,
        .navigation-paging .wp-pagenavi,
        .navigation-paging .nav-post-prev a, .navigation-paging .nav-post-next a,
        .comment-list .children li.comment,
        .wp-block-table,
        table,
        table td,
        table th,
        .woocommerce table.shop_attributes th,
        .woocommerce table.shop_attributes td,
        .woocommerce div.product .woocommerce-tabs ul.tabs:before,
        .woocommerce-cart .cart-collaterals .cart_totals table,
        #add_payment_method #payment ul.payment_methods, .woocommerce-cart #payment ul.payment_methods, .woocommerce-checkout #payment ul.payment_methods,
        .wp-block-separator,
        .navbar-center-wrapper,
        .nav .sub-menu li.menu-item > a,
        .davenport-card-post.davenport-post .davenport-post-details-wrapper,
        .sidebar .widget.widget_davenport_categories a,
        body .owl-theme .owl-dots .owl-dot span,
        .davenport-postline-block .davenport-postline-block-right,
        .davenport-postline2-block .davenport-list-post.davenport-list-small-post.davenport-post:after,
        .davenport-postsmasonry3-block-wrapper .col-md-7:not(:last-child) .davenport-post,
        .davenport-postsmasonry2-block-wrapper .col-md-5 .davenport-post:not(:last-child),
        .davenport-featured-categories-wrapper .davenport-featured-category .davenport-featured-category-info,
        blockquote,
        .blog-post-single .format-quote .entry-content,
        .post-review-block,
        .post-review-block .post-review-header,
        .post-review-block .post-review-summary,
        .post-review-block .post-review-criteria-group,
        .post-review-block .post-review-details,
        .single-post .davenport-post.davenport-post-bottom .post-details-bottom.post-details-bottom-single,
        .author-bio,
        .navigation-post,
        .navigation-post .nav-post-prev,
        .davenport-post .post-excerpt .post-readmore,
        .single-post .blog-post-related-wrapper .davenport-post,
        blockquote::before,
        .blog-post-single .format-quote .entry-content::before {
            border-color: rgba(255,255,255,0.1);
        }
        /* White border */
        .davenport-block .davenport-block-title,
        .single-post .blog-post-related-wrapper > h5,
        .comments-title {
            border-color: #ffffff;
        }
        /* White border top */
        .navbar-center-wrapper,
        .sidebar .widgettitle,
        blockquote,
        .blog-post-single .format-quote .entry-content {
            border-top-color: #ffffff;
        }
        /* White text */
        a:hover, a:focus,
        .davenport-post .post-title a,
        .davenport-post .post-title a:hover,
        .davenport-post .post-title,
        .davenport-post .post-author a,
        .davenport-post .post-author a:hover,
        .single-post .page-item-title-single .davenport-post .post-title:hover,
        h1, h2, h3, h4, h5, h6,
        .post-social-wrapper .post-social a,
        .davenport-post .post-details-bottom,
        .davenport-post .post-details-bottom a,
        .sidebar .widgettitle,
        .social-icons-wrapper a,
        header a.search-toggle-btn,
        .mainmenu-mobile-toggle,
        .author-bio h3 a:not(.btn),
        .author-bio .author-social-icons li a,
        .navigation-post a.nav-post-title-link,
        .navigation-post .nav-post-name,
        .blog-post-related-wrapper > h5,
        .comments-title,
        .comment-reply-title,
        .page-item-title-single .page-title,
        .sidebar .widget_calendar caption,
        .widget_recent_entries li a,
        .widget_recent_comments li a,
        .widget_categories li a,
        .widget_archive li a,
        .widget_meta li a,
        .widget_pages li a,
        .widget_rss li a,
        .widget_nav_menu li a,
        .sidebar .widget.widget_nav_menu a,
        .navigation-paging .wp-pagenavi a,
        .navigation-paging .nav-post-prev a, .navigation-paging .nav-post-next a,
        .wp-block-latest-posts a,
        .woocommerce ul.cart_list li a, .woocommerce ul.product_list_widget li a,
        .woocommerce ul.products li.product .woocommerce-loop-product__title,
        .woocommerce .woocommerce-breadcrumb a,
        .woocommerce .woocommerce-breadcrumb,
        .davenport-blog-posts-slider .davenport-post .post-title a:hover,
        .davenport-post .post-details-bottom .post-social-wrapper .post-social-title,
        .sidebar .widget.widget_davenport_categories a,
        .davenport-featured-categories-wrapper .davenport-featured-category .davenport-featured-category-link,
        blockquote::before,
        .blog-post-single .format-quote .entry-content::before,
        .davenport-post .post-title a:hover,
        .navigation-post .nav-post-name:hover,
        .navigation-post .nav-post-button-title,
        .single-post .blog-post-related-wrapper > h5,
        .page-item-title-archive .page-description,
        .woocommerce .woocommerce-error,
        .woocommerce .woocommerce-info,
        .woocommerce .woocommerce-message,
        .single-post.blog-enable-dropcaps .blog-post-single .post-content .entry-content > p:first-child:first-letter,
        .single-post .post-worthreading-post-wrapper .post-worthreading-post-button a {
            color: #ffffff;
        }
        .davenport-featured-categories-wrapper .davenport-featured-category .davenport-featured-category-link:hover {
            color: #ffffff!important;
        }
        /* Grey text */
        .davenport-postline-block .davenport-block-title h3,
        blockquote cite,
        .author-bio h5,
        .navigation-post .nav-post-title,
        .woocommerce ul.products li.product .price,
        .woocommerce div.product p.price, .woocommerce div.product span.price {
            color: #868686;
        }
        /* Black text */
        .davenport-social-share-fixed .post-social-wrapper .post-social a,
        .sidebar .widget_calendar tbody td a:hover {
            color: #000000;
        }
        /* Transparent background */
        .author-bio,
        .panel,
        table th,
        .woocommerce table.shop_table, #add_payment_method #payment, .woocommerce-checkout #payment,
        .woocommerce .order_details,
        .davenport-blog-posts-slider,
        header {
            background: transparent;
        }
        /* Dark background */
        .wp-block-latest-posts a,
        .davenport-postline-block,
        .davenport-overlay-post.davenport-post .davenport-post-wrapper-inner,
        .davenport-postline2-block-wrapper,
        body .owl-theme .owl-dots .owl-dot.active span,
        body .owl-theme .owl-dots .owl-dot:hover span,
        .davenport-subscribe-block,
        .davenport-featured-categories-wrapper .davenport-featured-category,
        .post-review-block .post-review-criteria-progress,
        .davenport-post .davenport-post-image-wrapper,
        .woocommerce .woocommerce-error,
        .woocommerce .woocommerce-info,
        .woocommerce .woocommerce-message {
            background-color: rgba(255,255,255,0.05);
        }
        .sidebar .widget.widget_davenport_social_icons a:hover,
        .single-post .davenport-social-share-fixed .post-social-wrapper .post-social a:hover {
            background-color: rgba(255,255,255,0.05)!important;
        }
        /* Black background */
        .wp-block-table tr:nth-child(2n+1) td,
        .davenport-posthighlight-block-wrapper .davenport-posthighlight-block .davenport-posthighlight-block-right .davenport-card-post.davenport-post {
            background-color: #000000;
        }
        /* Dark grey background */
        header.fixed,
        .davenport-featured-categories-wrapper .davenport-featured-category .davenport-featured-category-info,
        .davenport-post .post-details-bottom .post-social-wrapper .post-social,
        .page-item-title-archive .category-posts-count,
        .single-post .post-worthreading-post-container,
        .single-post .post-worthreading-post-wrapper {
            background-color: #0b0b0b;
        }
        .navbar .nav > li {
            background-image: linear-gradient(#ffffff, #ffffff), linear-gradient(transparent, transparent);
        }
        /* Remove margin for dark header */
        @media (min-width: 992px) {
            .home header.main-header, .blog header.main-header {
                margin-bottom: 0!important;
            }
            .container-page-item-title.container {
                margin-top: 0!important;
            }
        }
        /* Remove menu background */
        .nav .sub-menu li.menu-item > a:hover {
            background: none;
        }
        /* Remove menu shadow */
        header.main-header.fixed {
            box-shadow: none;
        }
        /* Show light logo */
        header .light-logo {
            display: block!important;
        }
        header .regular-logo {
            display: none!important;
        }
        <?php
    }

    $color_skin = get_theme_mod('color_skin', 'none');

    // Demo settings
    if ( defined('DEMO_MODE') && isset($_GET['color_skin']) ) {
      $color_skin = $_GET['color_skin'];
    }

    // Use panel settings
    if($color_skin == 'none') {

        $color_text = get_theme_mod('color_text', '#333333');
        $color_main = get_theme_mod('color_main', '#e58477');
        $color_button = get_theme_mod('color_button', '#121212');
        $color_button_hover = get_theme_mod('color_button_hover', '#48494b');
        $color_topmenu_bg =  get_theme_mod('color_topmenu_bg', '#FFFFFF');
        $color_topmenu_dark_bg = get_theme_mod('color_topmenu_dark_bg', '#121212');
        $color_mainmenu_submenu_bg = get_theme_mod('color_mainmenu_submenu_bg', '#FFFFFF');
        $color_mainmenu_link = get_theme_mod('color_mainmenu_link', '#000000');
        $color_mainmenu_link_hover = get_theme_mod('color_mainmenu_link_hover', '#e58477');
        $color_mainmenu_submenu_link = get_theme_mod('color_mainmenu_submenu_link', '#000000');
        $color_mainmenu_submenu_link_hover = get_theme_mod('color_mainmenu_submenu_link_hover', '#e58477');
        $color_footer_bg = get_theme_mod('color_footer_bg', '#FFFFFF');
        $color_footer_dark_bg = get_theme_mod('color_footer_dark_bg', '#1C1D1E');
        $color_slider_text = get_theme_mod('color_slider_text', '#000000');
        $color_post_reading_progressbar = get_theme_mod('color_post_reading_progressbar', '#000000');

    } else {

        // Same colors for all skins
        $color_text = '#000000';
        $color_button = '#121212';
        $color_button_hover = '#48494b';
        $color_topmenu_bg = '#FFFFFF';
        $color_topmenu_dark_bg = '#121212';
        $color_mainmenu_submenu_bg = '#FFFFFF';
        $color_mainmenu_link = '#000000';
        $color_mainmenu_submenu_link = '#000000';
        $color_footer_bg = '#FFFFFF';
        $color_footer_dark_bg = '#1C1D1E';
        $color_slider_text = '#000000';
        $color_post_reading_progressbar = '#000000';
    }

    // Default skin
    if($color_skin == 'default') {

        $color_main = '#e58477';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    // Black skin
    if($color_skin == 'dark') {

        $color_text = '#8e8e8e';
        $color_main = '#e58477';
        $color_button_hover = '#0b0b0b';
        $color_topmenu_bg =  '#FFFFFF';
        $color_topmenu_dark_bg = '#0b0b0b';
        $color_mainmenu_submenu_bg = '#0b0b0b';
        $color_mainmenu_link = '#ffffff';
        $color_mainmenu_link_hover = '#868686';
        $color_mainmenu_submenu_link = '#ffffff';
        $color_mainmenu_submenu_link_hover = '#868686';
        $color_footer_bg = '#FFFFFF';
        $color_footer_dark_bg = '#000000';
        $color_slider_text = '#000000';
        $color_post_reading_progressbar = '#e58477';

    }
    // Black skin
    if($color_skin == 'black') {

        $color_main = '#444444';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    // Grey skin
    if($color_skin == 'grey') {

        $color_main = '#62aed1';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    // Light blue skin
    if($color_skin == 'lightblue') {

        $color_main = '#62aed1';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    // Blue skin
    if($color_skin == 'blue') {

        $color_main = '#6284d1';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    // Red
    if($color_skin == 'red') {

        $color_main = '#e4393c';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    // Green
    if($color_skin == 'green') {

        $color_main = '#6cc49a';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    // Orange
    if($color_skin == 'orange') {

        $color_main = '#fab915';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    // RedOrange
    if($color_skin == 'redorange') {

        $color_main = '#e4393c';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    // Brown
    if($color_skin == 'brown') {

        $color_main = '#c6afa5';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    ?>
    <?php
    // Body background
    $body_background = get_theme_mod( 'body_background', false );

    if(!empty($body_background['background-image'])): ?>
    body {
        <?php
        echo 'background-image: url('.esc_url($body_background['background-image']).');';
        echo 'background-repeat: '.$body_background['background-repeat'].';';
        echo 'background-position: '.$body_background['background-position'].';';
        echo 'background-size: '.$body_background['background-size'].';';
        echo 'background-attachment: '.$body_background['background-attachment'].';';
        ?>
    }
    <?php endif; ?>

    body {
        color: <?php echo esc_html($color_text); ?>;
        background-color: <?php echo esc_html($body_background['background-color']); ?>;
    }
    .davenport-post .post-details-bottom .post-social-wrapper .post-social {
        background-color: <?php echo esc_html($body_background['background-color']); ?>;
    }

    .btn,
    .btn:focus,
    .btn:active,
    .btn-primary,
    .btn-primary:focus,
    .btn.alt:hover,
    .btn.btn-bordered:hover,
    .btn.btn-grey:hover,
    input[type="submit"],
    .woocommerce #content input.button,
    .woocommerce #respond input#submit,
    .woocommerce a.button,
    .woocommerce button.button,
    .woocommerce input.button,
    .woocommerce-page #content input.button,
    .woocommerce-page #respond input#submit,
    .woocommerce-page a.button,
    .woocommerce-page button.button,
    .woocommerce-page input.button,
    .woocommerce a.added_to_cart,
    .woocommerce-page a.added_to_cart,
    .woocommerce #content input.button.alt:hover,
    .woocommerce #respond input#submit.alt:hover,
    .woocommerce a.button.alt:hover,
    .woocommerce button.button.alt:hover,
    .woocommerce input.button.alt:hover,
    .woocommerce-page #content input.button.alt:hover,
    .woocommerce-page #respond input#submit.alt:hover,
    .woocommerce-page a.button.alt:hover,
    .woocommerce-page button.button.alt:hover,
    .woocommerce-page input.button.alt:hover,
    body .ig_popup.ig_inspire .ig_button,
    body .ig_popup.ig_inspire input[type="submit"],
    body .ig_popup.ig_inspire input[type="button"],
    .wp-block-button a.wp-block-button__link,
    .davenport-featured-categories-wrapper .davenport-featured-category .davenport-featured-category-counter,
    .sidebar .widget.widget_davenport_categories .post-categories-counter,
    .sidebar .widget.widget_davenport_categories a:not(.has-bg):hover {
        background-color: <?php echo esc_html($color_button); ?>;
        border-color: <?php echo esc_html($color_button); ?>;
    }

    .blog-post .tags a:hover,
    .post-social-wrapper .post-social-title a:hover,
    .sidebar .widget_calendar th,
    .sidebar .widget_calendar tfoot td,
    .sidebar .widget_tag_cloud .tagcloud a:hover,
    .sidebar .widget_product_tag_cloud .tagcloud a:hover,
    .comment-meta .reply a:hover,
    .comment-reply-title small a:hover,
    body .owl-theme .owl-controls .owl-page.active span,
    body .owl-theme .owl-controls.clickable .owl-page:hover span,
    .woocommerce .widget_price_filter .ui-slider .ui-slider-range,
    .woocommerce .widget_price_filter .ui-slider .ui-slider-handle,
    .davenport-post-block .post-categories a,
    .davenport-post .post-categories a,
    .single-post .blog-post-single .tags a:hover,
    .sidebar .widget .post-categories a {
        background-color: <?php echo esc_html($color_main); ?>;
    }

    .davenport-post .post-title a:hover {
        border-color: <?php echo esc_html($color_main); ?>;
    }

    a,
    .container-page-item-title.with-bg .post-info-share .post-social a:hover,
    .header-menu li a:hover,
    .author-bio .author-social-icons li a:hover,
    .post-social-wrapper .post-social a:hover,
    body .select2-results .select2-highlighted,
    .davenport-theme-block > h2,
    .btn.btn-text:hover,
    .social-icons-wrapper a:hover,
    .davenport-post-block .post-title:hover,
    .davenport-post-block .post-title a:hover,
    .navigation-paging.navigation-post a:hover,
    .navigation-paging .wp-pagenavi span.current,
    .navigation-paging .wp-pagenavi a:hover,
    .woocommerce ul.cart_list li a:hover,
    .woocommerce ul.product_list_widget li a:hover,
    .widget_recent_entries li a:hover,
    .widget_recent_comments li a:hover,
    .widget_categories li a:hover,
    .widget_archive li a:hover,
    .widget_meta li a:hover,
    .widget_pages li a:hover,
    .widget_rss li a:hover,
    .widget_nav_menu li a:hover,
    .comments-area .navigation-paging .nav-previous a:hover,
    .comments-area .navigation-paging .nav-next a:hover,
    .davenport-post .post-like-button:hover i.fa-heart-o,
    .davenport-featured-categories-wrapper .davenport-featured-category .davenport-featured-category-link:hover {
        color: <?php echo esc_html($color_main); ?>;
    }
    .btn:hover,
    .btn.btn-white:hover,
    .btn.alt,
    .btn-primary:hover,
    .btn-primary:active,
    input[type="submit"]:hover,
    .btn-black:hover,
    .woocommerce #content input.button.alt,
    .woocommerce #respond input#submit.alt,
    .woocommerce a.button.alt,
    .woocommerce button.button.alt,
    .woocommerce input.button.alt,
    .woocommerce-page #content input.button.alt,
    .woocommerce-page #respond input#submit.alt,
    .woocommerce-page a.button.alt,
    .woocommerce-page button.button.alt,
    .woocommerce-page input.button.alt,
    .woocommerce #content input.button:hover,
    .woocommerce #respond input#submit:hover,
    .woocommerce a.button:hover,
    .woocommerce button.button:hover,
    .woocommerce input.button:hover,
    .woocommerce-page #content input.button:hover,
    .woocommerce-page #respond input#submit:hover,
    .woocommerce-page a.button:hover,
    .woocommerce-page button.button:hover,
    .woocommerce-page input.button:hover,
    .wp-block-button a.wp-block-button__link:hover,
    .sidebar .widget.widget_davenport_categories a:hover .post-categories-counter,
    .davenport-post .post-details-bottom .post-social-wrapper .post-social a:hover,
    .sidebar .widget.widget_davenport_social_icons .social-icons-wrapper a:hover,
    body .owl-theme .owl-controls .owl-nav div.owl-prev:hover,
    body .owl-theme .owl-controls .owl-nav div.owl-next:hover,
    .single-post .davenport-social-share-fixed .post-social-wrapper .post-social a:hover {
        background-color: <?php echo esc_html($color_button_hover); ?>;
    }

    .btn:hover,
    .btn.btn-white:hover,
    .btn.alt,
    .btn-primary:hover,
    .btn-primary:active,
    .btn-black:hover,
    input[type="submit"]:hover,
    .woocommerce #content input.button.alt,
    .woocommerce #respond input#submit.alt,
    .woocommerce a.button.alt,
    .woocommerce button.button.alt,
    .woocommerce input.button.alt,
    .woocommerce-page #content input.button.alt,
    .woocommerce-page #respond input#submit.alt,
    .woocommerce-page a.button.alt,
    .woocommerce-page button.button.alt,
    .woocommerce-page input.button.alt,
    .woocommerce #content input.button:hover,
    .woocommerce #respond input#submit:hover,
    .woocommerce a.button:hover,
    .woocommerce button.button:hover,
    .woocommerce input.button:hover,
    .woocommerce-page #content input.button:hover,
    .woocommerce-page #respond input#submit:hover,
    .woocommerce-page a.button:hover,
    .woocommerce-page button.button:hover,
    .woocommerce-page input.button:hover {
        border-color: <?php echo esc_html($color_button_hover); ?>;
    }
    .nav > li .sub-menu {
        background-color: <?php echo esc_html($color_mainmenu_submenu_bg); ?>;
    }
    .nav .sub-menu li.menu-item > a {
        color: <?php echo esc_html($color_mainmenu_submenu_link); ?>;
    }
    .nav .sub-menu li.menu-item > a:hover {
        color: <?php echo esc_html($color_mainmenu_submenu_link_hover); ?>;
    }
    .navbar .nav > li > a {
        color: <?php echo esc_html($color_mainmenu_link); ?>;
    }
    .navbar .nav > li > a:hover {
        color: <?php echo esc_html($color_mainmenu_link_hover); ?>;
    }
    footer,
    .footer-sidebar-2-wrapper {
        background-color: <?php echo esc_html($color_footer_bg); ?>;
    }
    footer.footer-black,
    .footer-sidebar-2-wrapper.footer-black {
        background-color: <?php echo esc_html($color_footer_dark_bg); ?>;
    }
    .header-menu-bg,
    .header-menu-bg .header-menu li ul {
        background-color: <?php echo esc_html($color_topmenu_bg); ?>;
    }
    .header-menu-bg.menu_black,
    .header-menu-bg.menu_black .header-menu .menu-top-menu-container-toggle + div,
    .header-menu-bg.menu_black .header-menu li ul {
        background-color: <?php echo esc_html($color_topmenu_dark_bg); ?>;
    }
    .blog-post-reading-progress {
        border-color: <?php echo esc_html($color_post_reading_progressbar); ?>;
    }

    <?php
    	$out = ob_get_clean();

		$out .= ' /*' . date("Y-m-d H:i") . '*/';
		/* RETURN */
		return $out;
	}
    endif;
